# AI Signal Bot — Pocket Option (Telegram Mini App)

Application mobile (Telegram ou Safari sur iPhone) conçue pour **Pocket Option**. Elle propose :
- un écran Signal avec des timeframes 5s/10s/15s/1m et un sélecteur séparé pour la durée du trade ;
- un moteur d'analyse technique ;
- l'import de données historiques, un backtest complet et une simulation pas à pas ;
- des statistiques, des modèles IA optionnels, un bot Telegram et un arrêt d'urgence.

> ⚠️ **Données : non connecté · Exécution : non connecté.**
> Pocket Option ne propose pas d'API officielle. L'application ne produit donc **aucun signal en direct** et n'envoie **aucun ordre**. Le backtest et la simulation fonctionnent **uniquement sur les données que tu importes**, et sont toujours affichés comme « SIMULATION ».

---

## 1. Ce qui fonctionne réellement

| Fonction | État | Testé |
|---|---|---|
| Interface mobile FR/EN/ES, thème sombre, 6 onglets, installable sur l'écran d'accueil | ✅ | Captures en taille iPhone (390 px), aucune erreur JavaScript |
| Panneau « Données / Exécution : non connecté » | ✅ | ✅ |
| TIMEFRAME 5s · 10s · 15s · 1m et DURÉE 5s · 10s · 15s · 1m séparés | ✅ | ✅ |
| Durées limitées à celles que tu confirmes dans ton terminal Pocket Option | ✅ | ✅ |
| « ANALYSER LE MARCHÉ » → « Aucun signal — données indisponibles » (jamais de faux signal) | ✅ | ✅ |
| **Import de données** (bougies ou ticks, CSV) | ✅ | ✅ |
| **Backtest** : taux de réussite, intervalle de confiance, seuil de rentabilité, gain/perte, baisse max, série de pertes, UP vs DOWN, stabilité 70/30, courbe du solde | ✅ | ✅ |
| **Simulation pas à pas** avec solde virtuel (1, 10 ou 100 trades à la fois) | ✅ | ✅ |
| Statistiques séparées : signaux en direct (vides) / simulation (par timeframe et par durée) | ✅ | ✅ |
| Moteur : EMA 9/21/50, RSI 14, ATR 14, momentum, chandeliers, supports/résistances, filtre de volatilité, NO TRADE, seuil réglable | ✅ | ✅ (valeurs de référence) |
| Modèles IA Claude / OpenAI : « Non connecté » sans clé, relecture du signal avec clé | ✅ | ✅ (appels simulés, pas d'appel réel) |
| Bot Telegram : /start avec bouton qui ouvre l'appli, /status, bouton de menu, configuration en 1 clic | ✅ | ✅ (API Telegram simulée, pas de vrai bot) |
| Arrêt d'urgence : bloque ordres, simulation pas à pas et exécution automatique | ✅ | ✅ |
| Sécurité : signature Telegram vérifiée, liste d'ID autorisés, clé d'accès, limite de requêtes, secrets côté serveur | ✅ | ✅ |

## 2. Ce qui nécessite un accès autorisé à Pocket Option

| Fonction | Pourquoi c'est bloqué |
|---|---|
| Signaux UP/DOWN en direct (OTC ou marché réel) | Aucune source de prix Pocket Option autorisée |
| Vérification gagné/perdu des signaux en direct | Il faut le prix à l'expiration |
| Simulation en direct (mode « Simulation » des Réglages) | Il faut des prix en direct pour vérifier |
| Ordres démo / réels, exécution automatique | Aucune API d'ordres officielle |
| Liste d'actifs et durées vérifiées automatiquement | Il faut un accès à la plateforme : tu les déclares toi-même dans Réglages |

Si un accès officiel apparaît, il suffit de compléter `PocketOptionFeed` dans `market.py` (`get_candles_tf` et `get_price_at`). Des tests vérifient déjà que tout le reste fonctionne avec un tel flux.

---

## 3. Importer des données (onglet 🧪 Tests)

Fichier texte ou CSV, une ligne par bougie ou par tick. L'en-tête est facultatif.

**Bougies** — `temps,open,high,low,close` (une colonne volume en plus est ignorée)
```
time,open,high,low,close
1760700000,1.10012,1.10020,1.10005,1.10015
1760700005,1.10015,1.10019,1.10010,1.10011
```
**Ticks** — `temps,prix`
```
time,price
1760700000,1.10012
1760700001,1.10014
```
- **Temps** : secondes Unix, millisecondes Unix, ou date `2026-10-17 14:30:05` (UTC si aucun fuseau n'est indiqué).
- **Séparateur** : `,` ou `;`. Avec `;`, la virgule décimale est acceptée (export Excel français).
- Les bougies doivent être régulières : 5s, 10s, 15s ou 1m, avec moins de 5 % de trous.
- **Rien n'est inventé.** Des bougies de 5s peuvent être regroupées en 10s, 15s ou 1m (périodes complètes uniquement). Le contraire est impossible : pas de 5s à partir de 1m. Des ticks sont regroupés en bougies seulement s'ils sont assez fréquents.
- Les fichiers `modele_import_bougies.csv` et `modele_import_ticks.csv` contiennent juste les en-têtes.

**D'où peuvent venir les données ?** Relevés que tu as faits toi-même, ou un fournisseur de données que tu as le droit d'utiliser. Indique toujours l'origine dans le champ prévu. Des données d'un autre fournisseur ne sont **pas** des prix Pocket Option, et l'interface ne le prétend jamais.

**Taille maximale** : 3 Mo, 100 000 lignes.

## 4. Backtest et simulation : comment c'est calculé

- À chaque décision, le moteur ne voit que les 200 bougies **passées**, comme en direct. Aucune information future n'est utilisée.
- **Entrée** = clôture de la dernière bougie connue. **Sortie** = clôture de la bougie à l'expiration (durée ÷ timeframe bougies plus tard). La durée doit donc être un multiple du timeframe : 5s → 5s, 10s, 15s ou 1m ; 15s → 15s ou 1m ; 1m → 1m.
- Un seul trade à la fois : le suivant n'est pris qu'après l'expiration du précédent.
- **Gagné** = +mise × gain (85 % par défaut, réglable). **Perdu** = −mise. **Égalité** = 0.
- Si un trou dans les données tombe entre l'entrée et l'expiration, le trade est **ignoré**, jamais deviné.
- **Seuil de rentabilité** = 1 ÷ (1 + gain). Avec 85 %, il faut plus de **54,1 %** de réussite.
- **Intervalle de confiance 95 % (Wilson)** : si sa borne basse est sous le seuil de rentabilité, rien n'est prouvé. En dessous de 30 trades, l'appli affiche « échantillon trop petit ».
- **Stabilité 70/30** : compare les 70 % premiers trades aux 30 % derniers. Un grand écart signale un résultat fragile.

---

## 5. Déploiement depuis l'iPhone

### A — Mettre le code sur GitHub
1. App **Fichiers** : touche `aibot.zip` pour le décompresser.
2. Safari → **github.com** → crée un compte → **+ → New repository** → nom `ai-signal-bot`, coche **Private** → **Create repository**.
3. Touche **uploading an existing file** et sélectionne tous les fichiers de la racine du dossier `aibot`. Puis **Commit changes**.
4. Pour chaque dossier (`static`, puis `tests`) :
   - **Add file → Create new file** ;
   - tape `static/x` comme nom (le `/` crée le dossier) et valide ;
   - ouvre le dossier → **Add file → Upload files** → envoie ses fichiers ;
   - supprime le fichier `x`.

   Dans `static`, il y a 6 fichiers : index.html, app.js, style.css, manifest.json, icon-192.png, icon-512.png.

### B — Héberger gratuitement sur Render
1. **render.com** → **Sign in with GitHub**.
2. **New → Blueprint** → choisis `ai-signal-bot` → **Apply**. Render lit `render.yaml` tout seul.
3. Attends 3 à 5 minutes. Tu obtiens une adresse `https://ai-signal-bot-xxxx.onrender.com`.
4. Ouvre ton service → **Environment** → note la valeur de `ACCESS_KEY` : c'est ton mot de passe.
5. Ouvre l'adresse dans Safari et entre l'`ACCESS_KEY`.
6. **Bouton Partager → Sur l'écran d'accueil** : l'appli s'installe comme une app.

### C — Connecter Telegram
1. Dans Telegram, ouvre **@BotFather** → `/newbot` → choisis un nom → copie le **token**.
2. Ouvre **@userinfobot** → copie ton **ID** (un nombre).
3. Render → **Environment** :
   - `TELEGRAM_BOT_TOKEN` = le token ;
   - `ALLOWED_TELEGRAM_IDS` = ton ID.

   Enregistre : Render redémarre.
4. Dans l'appli (Safari) → **Réglages → Telegram → Configurer le bot Telegram**. Cela enregistre le webhook, les commandes et le bouton « Signal ».
5. Ouvre ton bot dans Telegram → `/start` → touche **📈 Ouvrir AI Signal Bot**.

Sécurité : si `ALLOWED_TELEGRAM_IDS` est vide, **personne** n'entre par Telegram. Un inconnu qui tape /start voit seulement son propre ID et un refus.

### D — Première utilisation
1. **Réglages → Configuration Pocket Option** :
   - coche les durées que tu vois dans ton terminal Pocket Option ;
   - ajuste la liste des actifs (un par ligne, avec « OTC » à la fin pour les actifs OTC).
2. **Tests** :
   - importe un fichier ;
   - choisis le timeframe, la durée, la mise, le gain et le seuil ;
   - lance le **backtest** ;
   - démarre une **simulation** et avance par 1, 10 ou 100 trades.
3. **Stats** : résultats de simulation séparés par timeframe et par durée.

---

## 6. Architecture et fichiers

```
aibot/
├── main.py            routes API, webhook Telegram, vérification des résultats
├── market.py          Pocket Option (non connecté), timeframes, durées, import CSV,
│                      regroupement de bougies, bougies depuis ticks
├── engine.py          moteur d'analyse, simulation sans regard vers le futur, résumé statistique
├── indicators.py      EMA, RSI, ATR, momentum, chandeliers, supports/résistances
├── trading.py         modes, limites de risque, arrêt d'urgence
├── storage.py         SQLite : signaux, jeux de données, simulations, stats, réglages
├── ai_providers.py    Claude / OpenAI (optionnels)
├── telegram_bot.py    /start, /status, webhook, bouton de menu
├── security.py        signature Telegram, clé d'accès, limite de requêtes
├── config.py          variables d'environnement
├── requirements.txt   render.yaml   .env.example   .gitignore
├── modele_import_bougies.csv   modele_import_ticks.csv
├── static/            index.html  app.js  style.css  manifest.json  icon-192.png  icon-512.png
└── tests/             78 tests automatiques
```

## 7. Tests automatiques
```
pip install -r requirements.txt
python -m pytest -q
```
**78 tests, tous réussis.** Ils couvrent :
- **Indicateurs** : RSI sur la série de référence de Wilder (≈ 70,5), EMA et ATR exacts, figures de chandeliers.
- **Moteur** : refus des données périmées ou insuffisantes, seuil réglable, absence de regard vers le futur, un trade à la fois, trous ignorés, calculs du résumé (solde, baisse max, séries, seuil de rentabilité).
- **Import** : bougies, ticks, dates ISO, millisecondes, `;` et virgule décimale, erreurs, refus de créer des 5s à partir de 1m, regroupement en périodes complètes.
- **API** : statut « non connecté », aucun signal sans données, durées à confirmer, modes indisponibles, backtest, simulation jusqu'à la fin des données, statistiques, arrêt d'urgence, limites de risque.
- **IA** : appels Claude et OpenAI simulés, réponse invalide rejetée.
- **Telegram** : bouton web_app, refus des ID non autorisés, webhook protégé par secret, configuration.
- **Sécurité** : signature Telegram, liste d'ID, limite de requêtes.

Les données utilisées par les tests sont **synthétiques** et servent uniquement à vérifier les calculs.

## 8. Limites
- **Non déployé et jamais connecté à Pocket Option, à Telegram ou aux API IA en conditions réelles.** Ces connexions ont été testées avec des réponses simulées.
- Les durées très courtes (5 à 15 s) sont proches du hasard : un backtest favorable sur peu de trades ne prouve rien.
- Un fichier de ticks doit être continu : une longue interruption (week-end) fait refuser les timeframes trop fins.
- **Render gratuit** : mise en veille après environ 15 minutes sans visite (premier chargement lent). La base SQLite, avec les données importées et les simulations, est effacée à chaque redéploiement. Pour la garder, il faut un disque persistant (offre payante) et `DATABASE_PATH` pointant dessus.
- Volume et calendrier économique non utilisés.
