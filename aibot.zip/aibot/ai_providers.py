"""Fournisseurs IA (optionnels). Les clés restent côté serveur.

Rôle de l'IA : relire les indicateurs calculés et CONFIRMER ou REJETER le signal technique.
Elle ne peut pas inventer de prix : elle ne reçoit que les valeurs calculées.
Si elle rejette, le signal devient NO_TRADE."""
import json
from typing import Dict, List

import httpx

from config import settings

PROMPT = """Tu es un analyste technique prudent. Voici des indicateurs calculés sur des données réelles
pour {symbol}, bougies de {timeframe}, expiration du trade {duration}. Le moteur technique propose : {direction} (score {score}/100).
Indicateurs : {indicators}
Raisons du moteur : {reasons}
Réponds UNIQUEMENT en JSON : {{"verdict": "AGREE" | "DISAGREE", "note": "<une phrase courte en {lang}>"}}.
Dis DISAGREE si les signaux sont contradictoires ou faibles. N'invente aucun chiffre."""

_transport = None  # remplacé dans les tests (httpx.MockTransport)

LANG_NAMES = {"fr": "français", "en": "English", "es": "español"}


def providers() -> List[Dict]:
    return [
        {"id": "technical", "name": "Moteur technique (local)", "connected": True,
         "desc": "EMA, RSI, ATR, momentum, chandeliers, supports/résistances"},
        {"id": "claude", "name": f"Claude ({settings.CLAUDE_MODEL})",
         "connected": bool(settings.ANTHROPIC_API_KEY),
         "desc": "Moteur technique + relecture par Claude (API Anthropic)"},
        {"id": "openai", "name": f"OpenAI ({settings.OPENAI_MODEL or '—'})",
         "connected": bool(settings.OPENAI_API_KEY and settings.OPENAI_MODEL),
         "desc": "Moteur technique + relecture par un modèle OpenAI"},
    ]


def is_connected(pid: str) -> bool:
    return any(p["id"] == pid and p["connected"] for p in providers())


def _parse(text: str) -> Dict:
    start, end = text.find("{"), text.rfind("}")
    data = json.loads(text[start:end + 1])
    verdict = str(data.get("verdict", "")).upper()
    if verdict not in ("AGREE", "DISAGREE"):
        raise ValueError("Réponse IA invalide")
    return {"verdict": verdict, "note": str(data.get("note", ""))[:300]}


async def review(pid: str, symbol: str, timeframe: str, duration: str, result: Dict, lang: str = "fr") -> Dict:
    prompt = PROMPT.format(symbol=symbol, timeframe=timeframe, duration=duration, direction=result["direction"],
                           score=result["score"], indicators=json.dumps(result["indicators"]),
                           reasons=json.dumps(result["reasons"]), lang=LANG_NAMES.get(lang, "français"))
    async with httpx.AsyncClient(timeout=30, transport=_transport) as client:
        if pid == "claude":
            r = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={"x-api-key": settings.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01",
                         "content-type": "application/json"},
                json={"model": settings.CLAUDE_MODEL, "max_tokens": 200,
                      "messages": [{"role": "user", "content": prompt}]})
            r.raise_for_status()
            text = "".join(b.get("text", "") for b in r.json().get("content", []))
        elif pid == "openai":
            r = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {settings.OPENAI_API_KEY}"},
                json={"model": settings.OPENAI_MODEL, "response_format": {"type": "json_object"},
                      "messages": [{"role": "user", "content": prompt}]})
            r.raise_for_status()
            text = r.json()["choices"][0]["message"]["content"]
        else:
            raise ValueError("Fournisseur inconnu")
    return _parse(text)
