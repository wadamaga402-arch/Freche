"""Configuration lue UNIQUEMENT depuis les variables d'environnement (côté serveur).
Aucun secret n'est jamais envoyé au navigateur ou à Telegram."""
import os


def _bool(name: str, default: bool = False) -> bool:
    return os.getenv(name, str(default)).strip().lower() in ("1", "true", "yes", "on")


def _float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except ValueError:
        return default


class Settings:
    # --- Accès à l'application ---
    TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
    ALLOWED_TELEGRAM_IDS = {
        x.strip() for x in os.getenv("ALLOWED_TELEGRAM_IDS", "").split(",") if x.strip()
    }
    ACCESS_KEY = os.getenv("ACCESS_KEY", "")  # mot de passe d'accès pour tester dans Safari
    # Adresse publique du site (Render la fournit automatiquement dans RENDER_EXTERNAL_URL)
    PUBLIC_URL = os.getenv("PUBLIC_URL") or os.getenv("RENDER_EXTERNAL_URL", "")

    # --- Plateforme cible : Pocket Option ---
    # Aucune API officielle : aucune variable de connexion. Ne mettez JAMAIS votre mot de passe
    # ou votre session Pocket Option ici.

    # --- IA ---
    ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
    CLAUDE_MODEL = os.getenv("CLAUDE_MODEL", "claude-sonnet-5-5")
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
    OPENAI_MODEL = os.getenv("OPENAI_MODEL", "")  # obligatoire si OpenAI utilisé

    # --- Actualités (optionnel) ---
    FINNHUB_API_KEY = os.getenv("FINNHUB_API_KEY", "")

    # --- Exécution & risque ---
    MAX_STAKE = _float("MAX_STAKE", 5.0)
    DAILY_LOSS_LIMIT = _float("DAILY_LOSS_LIMIT", 20.0)
    MAX_TRADES_PER_DAY = int(_float("MAX_TRADES_PER_DAY", 20))
    SIM_START_BALANCE = _float("SIM_START_BALANCE", 1000.0)
    SIM_PAYOUT = _float("SIM_PAYOUT", 0.85)  # gain simulé si gagnant (85 % de la mise)

    # --- Divers ---
    DATABASE_PATH = os.getenv("DATABASE_PATH", "data.db")
    RATE_LIMIT_PER_MIN = int(_float("RATE_LIMIT_PER_MIN", 20))
    MIN_CALIBRATION_SAMPLES = int(_float("MIN_CALIBRATION_SAMPLES", 30))


settings = Settings()
