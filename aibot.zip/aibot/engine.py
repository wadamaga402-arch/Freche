"""Moteur d'analyse technique déterministe.

Il ne fabrique aucune donnée : il refuse d'analyser si les bougies sont absentes,
insuffisantes ou trop anciennes (DataError) et peut répondre NO_TRADE."""
import time
from typing import Dict, List, Optional, Tuple

import indicators as ind

MIN_CANDLES = 60
SCORE_THRESHOLD = 40


class DataError(Exception):
    """Données indisponibles ou inutilisables : on n'émet PAS de signal."""

    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


def check_data(candles: List[Dict], granularity: int, now: Optional[float] = None) -> None:
    now = now or time.time()
    if not candles:
        raise DataError("no_data", "Aucune donnée de marché reçue.")
    if len(candles) < MIN_CANDLES:
        raise DataError("insufficient_data", f"Seulement {len(candles)} bougies (minimum {MIN_CANDLES}).")
    age = now - candles[-1]["epoch"]
    if age > max(granularity * 3, 30):
        raise DataError("stale_data", f"Dernière bougie vieille de {int(age // 60)} min : marché fermé ou flux interrompu.")


def analyze(candles: List[Dict], granularity: int, duration_sec: int,
            market_type: str = "rise_fall", now: Optional[float] = None,
            threshold: int = SCORE_THRESHOLD, last_closed: bool = False) -> Dict:
    """granularity = timeframe d'analyse (s) ; duration_sec = expiration du trade (s).
    last_closed=True quand toutes les bougies sont clôturées (historique / backtest)."""
    check_data(candles, granularity, now)
    closes = [c["close"] for c in candles]
    price = closes[-1]
    closed = candles if last_closed else candles[:-1]  # en direct, la dernière bougie est en formation
    score = 0
    reasons = []

    # 1) Tendance (EMA 9 / 21 / 50)
    e9, e21, e50 = ind.ema(closes, 9)[-1], ind.ema(closes, 21)[-1], ind.ema(closes, 50)[-1]
    if e9 > e21 > e50:
        score += 30; reasons.append({"key": "trend_up"})
    elif e9 < e21 < e50:
        score -= 30; reasons.append({"key": "trend_down"})
    else:
        reasons.append({"key": "trend_mixed"})
    if price > e50:
        score += 10
    elif price < e50:
        score -= 10

    # 2) RSI
    r = ind.rsi(closes, 14)
    if r is not None:
        if r >= 75:
            score -= 20; reasons.append({"key": "rsi_overbought", "v": {"rsi": round(r, 1)}})
        elif r <= 25:
            score += 20; reasons.append({"key": "rsi_oversold", "v": {"rsi": round(r, 1)}})
        elif r > 55:
            score += 10; reasons.append({"key": "rsi_bull", "v": {"rsi": round(r, 1)}})
        elif r < 45:
            score -= 10; reasons.append({"key": "rsi_bear", "v": {"rsi": round(r, 1)}})
        else:
            reasons.append({"key": "rsi_neutral", "v": {"rsi": round(r, 1)}})

    # 3) Momentum
    roc = ind.rate_of_change(closes, 10)
    a = ind.atr(candles, 14)
    if roc is not None and a:
        move = closes[-1] - closes[-11]
        if move > a:
            score += 15; reasons.append({"key": "momentum_up"})
        elif move < -a:
            score -= 15; reasons.append({"key": "momentum_down"})

    # 4) Chandeliers
    pat = ind.candle_pattern(closed)
    if pat in ("bullish_engulfing", "hammer"):
        score += 15
    elif pat in ("bearish_engulfing", "shooting_star"):
        score -= 15
    if pat:
        reasons.append({"key": "pattern", "v": {"name": pat}})

    # 5) Supports / résistances
    sup, res = ind.support_resistance(closed)
    near = (a or 0) * 0.5
    if res is not None and score > 0 and res - price < near:
        score -= 20; reasons.append({"key": "near_resistance", "v": {"level": res}})
    if sup is not None and score < 0 and price - sup < near:
        score += 20; reasons.append({"key": "near_support", "v": {"level": sup}})

    # 6) Volatilité (filtre)
    vol_pct = (a / price * 100) if a and price else 0
    volatility_ok = True
    if a is not None:
        # ATR moyen des 50 bougies précédentes pour détecter un pic anormal
        hist = ind.atr(candles[:-10], 14)
        if hist and a > 2.5 * hist:
            volatility_ok = False; reasons.append({"key": "vol_spike"})
        elif vol_pct < 0.002:
            volatility_ok = False; reasons.append({"key": "vol_flat"})
    # 7) Cohérence timeframe / expiration (deux paramètres distincts)
    if duration_sec < granularity:
        reasons.append({"key": "horizon_short"})
    elif duration_sec > granularity * 30:
        reasons.append({"key": "horizon_long"})
    reasons.append({"key": "no_volume"})        # volume non fourni par la source
    reasons.append({"key": "no_calendar"})      # pas de calendrier économique connecté

    score = max(-100, min(100, score))
    if not volatility_ok or abs(score) < threshold:
        direction = "NO_TRADE"
    else:
        direction = "UP" if score > 0 else "DOWN"

    action = direction
    if market_type == "forex" and direction != "NO_TRADE":
        action = "BUY" if direction == "UP" else "SELL"

    return {
        "direction": direction,
        "action": action,
        "score": score,
        "price": price,
        "data_epoch": candles[-1]["epoch"],
        "indicators": {
            "ema9": e9, "ema21": e21, "ema50": e50, "rsi": r, "atr": a,
            "roc": roc, "support": sup, "resistance": res, "pattern": pat,
            "volatility_pct": vol_pct,
        },
        "reasons": reasons,
    }


WINDOW = 200   # nombre de bougies analysées à chaque décision (comme en direct)
WARMUP = 80    # première décision possible


def steps_for(granularity: int, duration_sec: int) -> int:
    if duration_sec < granularity or duration_sec % granularity:
        raise DataError("backtest_mismatch", "La durée doit être un multiple du timeframe (ex. 5s → 15s, 15s → 1m).")
    return duration_sec // granularity


def simulate(candles: List[Dict], granularity: int, duration_sec: int, start: int = WARMUP,
             max_events: Optional[int] = None, stake: float = 1.0, payout: float = 0.85,
             threshold: int = SCORE_THRESHOLD, max_trades: Optional[int] = None) -> Tuple[List[Dict], int]:
    """Rejoue le moteur sur des bougies HISTORIQUES réelles, un trade à la fois (pas de chevauchement).

    À l'index i, le moteur ne voit que les bougies [i-200, i) : aucune information future.
    Entrée = clôture de la bougie i-1 ; sortie = clôture de la bougie i-1+n (n = durée / timeframe).
    Égalité = remboursement (profit 0). Retourne (événements, index suivant)."""
    n = steps_for(granularity, duration_sec)
    events: List[Dict] = []
    trades_done = 0
    i = max(start, WARMUP)
    while i + n - 1 < len(candles):
        if max_events is not None and len(events) >= max_events:
            break
        if max_trades is not None and trades_done >= max_trades:
            break
        window = candles[max(0, i - WINDOW):i]
        try:
            res = analyze(window, granularity, duration_sec, now=window[-1]["epoch"],
                          threshold=threshold, last_closed=True)
        except DataError:
            i += 1
            continue
        entry_c = window[-1]
        if res["direction"] == "NO_TRADE":
            events.append({"i": i, "epoch": entry_c["epoch"], "direction": "NO_TRADE", "score": res["score"],
                           "outcome": "no_trade", "profit": 0.0})
            i += 1
            continue
        exit_c = candles[i - 1 + n]
        if exit_c["epoch"] - entry_c["epoch"] != n * granularity:
            # trou dans les données entre l'entrée et l'expiration : résultat non vérifiable, on n'invente rien
            events.append({"i": i, "epoch": entry_c["epoch"], "direction": res["direction"], "score": res["score"],
                           "outcome": "skipped_gap", "profit": 0.0})
            i += 1
            continue
        entry, exit_ = entry_c["close"], exit_c["close"]
        if exit_ == entry:
            outcome, profit = "draw", 0.0
        elif (exit_ > entry) == (res["direction"] == "UP"):
            outcome, profit = "won", round(stake * payout, 4)
        else:
            outcome, profit = "lost", -stake
        events.append({"i": i, "epoch": entry_c["epoch"], "exit_epoch": exit_c["epoch"] + granularity,
                       "direction": res["direction"], "score": res["score"], "entry": entry, "exit": exit_,
                       "outcome": outcome, "profit": profit})
        trades_done += 1
        i += n  # on attend l'expiration avant le trade suivant
    return events, i


def summarize(events: List[Dict], stake: float, payout: float, start_balance: float = 1000.0) -> Dict:
    trades = [e for e in events if e["outcome"] in ("won", "lost", "draw")]
    wins = sum(e["outcome"] == "won" for e in trades)
    losses = sum(e["outcome"] == "lost" for e in trades)
    draws = sum(e["outcome"] == "draw" for e in trades)
    bal, peak, max_dd, streak, max_streak = start_balance, start_balance, 0.0, 0, 0
    curve = [round(bal, 2)]
    for e in trades:
        bal += e["profit"]
        curve.append(round(bal, 2))
        peak = max(peak, bal)
        max_dd = max(max_dd, peak - bal)
        streak = streak + 1 if e["outcome"] == "lost" else (streak if e["outcome"] == "draw" else 0)
        max_streak = max(max_streak, streak)
    decided = wins + losses

    def rate(sub):
        w = sum(e["outcome"] == "won" for e in sub)
        l = sum(e["outcome"] == "lost" for e in sub)
        return {"n": w + l, "wins": w, "win_rate": (w / (w + l)) if w + l else None}

    cut = int(len(trades) * 0.7)
    step = max(1, len(curve) // 200)
    return {
        "trades": len(trades), "wins": wins, "losses": losses, "draws": draws,
        "no_trade": sum(e["outcome"] == "no_trade" for e in events),
        "skipped_gap": sum(e["outcome"] == "skipped_gap" for e in events),
        "win_rate": (wins / decided) if decided else None,
        "breakeven": 1 / (1 + payout),
        "pnl": round(bal - start_balance, 2), "start_balance": start_balance, "final_balance": round(bal, 2),
        "max_drawdown": round(max_dd, 2), "max_loss_streak": max_streak,
        "stake": stake, "payout": payout,
        "up": rate([e for e in trades if e["direction"] == "UP"]),
        "down": rate([e for e in trades if e["direction"] == "DOWN"]),
        "first_70": rate(trades[:cut]), "last_30": rate(trades[cut:]),
        "equity": curve[::step] + ([curve[-1]] if (len(curve) - 1) % step else []),
        "last_trades": trades[-30:][::-1],
    }


def backtest(candles: List[Dict], granularity: int, duration_sec: int, stake: float = 1.0,
             payout: float = 0.85, threshold: int = SCORE_THRESHOLD) -> Dict:
    """Test complet sur données historiques importées (séparé de tout résultat réel)."""
    events, _ = simulate(candles, granularity, duration_sec, stake=stake, payout=payout, threshold=threshold)
    return summarize(events, stake, payout)
