"""Indicateurs techniques calculés à partir de bougies réelles (pas de données inventées)."""
from typing import List, Dict, Optional


def ema(values: List[float], period: int) -> List[Optional[float]]:
    out: List[Optional[float]] = [None] * len(values)
    if len(values) < period:
        return out
    k = 2 / (period + 1)
    prev = sum(values[:period]) / period
    out[period - 1] = prev
    for i in range(period, len(values)):
        prev = values[i] * k + prev * (1 - k)
        out[i] = prev
    return out


def rsi(closes: List[float], period: int = 14) -> Optional[float]:
    if len(closes) <= period:
        return None
    gains, losses = 0.0, 0.0
    for i in range(1, period + 1):
        d = closes[i] - closes[i - 1]
        gains += max(d, 0)
        losses += max(-d, 0)
    avg_g, avg_l = gains / period, losses / period
    for i in range(period + 1, len(closes)):
        d = closes[i] - closes[i - 1]
        avg_g = (avg_g * (period - 1) + max(d, 0)) / period
        avg_l = (avg_l * (period - 1) + max(-d, 0)) / period
    if avg_l == 0:
        return 100.0
    rs = avg_g / avg_l
    return 100 - 100 / (1 + rs)


def atr(candles: List[Dict], period: int = 14) -> Optional[float]:
    if len(candles) <= period:
        return None
    trs = []
    for i in range(1, len(candles)):
        h, l, pc = candles[i]["high"], candles[i]["low"], candles[i - 1]["close"]
        trs.append(max(h - l, abs(h - pc), abs(l - pc)))
    val = sum(trs[:period]) / period
    for tr in trs[period:]:
        val = (val * (period - 1) + tr) / period
    return val


def rate_of_change(closes: List[float], period: int = 10) -> Optional[float]:
    if len(closes) <= period or closes[-period - 1] == 0:
        return None
    return (closes[-1] - closes[-period - 1]) / closes[-period - 1] * 100


def support_resistance(candles: List[Dict], lookback: int = 60, wing: int = 3):
    """Niveaux = points pivots (swing highs / lows) sur la fenêtre récente."""
    data = candles[-lookback:]
    highs, lows = [], []
    for i in range(wing, len(data) - wing):
        h, l = data[i]["high"], data[i]["low"]
        if all(h >= data[j]["high"] for j in range(i - wing, i + wing + 1)):
            highs.append(h)
        if all(l <= data[j]["low"] for j in range(i - wing, i + wing + 1)):
            lows.append(l)
    price = candles[-1]["close"]
    res = min([h for h in highs if h > price], default=None)
    sup = max([l for l in lows if l < price], default=None)
    return sup, res


def candle_pattern(candles: List[Dict]) -> Optional[str]:
    """Détecte quelques figures simples sur les 2 dernières bougies clôturées."""
    if len(candles) < 2:
        return None
    p, c = candles[-2], candles[-1]
    body = abs(c["close"] - c["open"])
    rng = c["high"] - c["low"]
    if rng == 0:
        return None
    upper = c["high"] - max(c["open"], c["close"])
    lower = min(c["open"], c["close"]) - c["low"]
    if c["close"] > c["open"] and p["close"] < p["open"] and c["close"] >= p["open"] and c["open"] <= p["close"]:
        return "bullish_engulfing"
    if c["close"] < c["open"] and p["close"] > p["open"] and c["close"] <= p["open"] and c["open"] >= p["close"]:
        return "bearish_engulfing"
    if lower > 2 * body and upper < body:
        return "hammer"
    if upper > 2 * body and lower < body:
        return "shooting_star"
    if body < 0.1 * rng:
        return "doji"
    return None
