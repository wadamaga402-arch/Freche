"""Serveur principal : API + interface web (Telegram Mini App), plateforme cible Pocket Option."""
import asyncio
import logging
import time
from contextlib import asynccontextmanager
from typing import List, Optional

import json

import httpx
from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import ai_providers
import engine
import market
import storage
import telegram_bot
import trading
from config import settings
from security import enforce_heavy_limit, require_user

logging.basicConfig(level=logging.INFO)


# ---------- Vérification automatique des résultats ----------
async def resolve_pending_once() -> int:
    """Vérifie les signaux expirés avec le prix réel de la plateforme.
    Sans source connectée, les signaux restent « en attente » : rien n'est supposé."""
    done = 0
    for s in storage.pending_signals(int(time.time()) - 2):
        try:
            tick = await market.feed.get_price_at(s["symbol"], s["expiry_epoch"])
        except market.PlatformNotConnected:
            break
        except Exception as e:
            storage.log("warning", f"Vérification signal {s['id']} impossible : {e}")
            continue
        tolerance = min(120, max(4, (s["duration_sec"] or 60) // 2))
        if s["expiry_epoch"] - tick["epoch"] > tolerance:
            storage.set_signal_result(s["id"], "unverifiable", None, None)
            continue
        outcome = storage.resolve_outcome(s["direction"], s["price"], tick["price"])
        storage.set_signal_result(s["id"], outcome, tick["price"], tick["epoch"])
        trading.settle_simulated(s["id"], outcome)
        done += 1
    return done


async def resolver_loop():
    while True:
        try:
            await resolve_pending_once()
        except Exception as e:
            storage.log("error", f"Boucle de vérification : {e}")
        await asyncio.sleep(5)


@asynccontextmanager
async def lifespan(app: FastAPI):
    storage.init_db()
    task = asyncio.create_task(resolver_loop())
    yield
    task.cancel()


app = FastAPI(title="AI Signal Bot — Pocket Option", lifespan=lifespan)


# ---------- Modèles de requêtes ----------
class SignalReq(BaseModel):
    symbol: str
    timeframe: str          # timeframe d'ANALYSE : 5s, 10s, 15s, 1m
    duration_sec: int       # durée d'EXPIRATION : 5, 10, 15, 60
    model: str = "technical"
    lang: str = "fr"


class ExecuteReq(BaseModel):
    signal_id: int
    confirm_real: bool = False


class SettingsReq(BaseModel):
    mode: Optional[str] = None
    stake: Optional[float] = None
    auto_execute: Optional[bool] = None
    assets: Optional[List[str]] = None
    po_expiries: Optional[List[int]] = None


class HaltReq(BaseModel):
    halted: bool


class DatasetReq(BaseModel):
    name: str
    label: str = ""
    csv: str


class BacktestReq(BaseModel):
    dataset_id: int
    timeframe: str
    duration_sec: int
    stake: float = 1.0
    payout: float = 0.85
    threshold: int = engine.SCORE_THRESHOLD


class ReplayStartReq(BacktestReq):
    start_balance: float = 1000.0


class ReplayStepReq(BaseModel):
    n: int = 1   # nombre de trades à jouer


MAX_CSV_CHARS = 3_000_000


def _check_test_params(req: BacktestReq) -> int:
    tf = market.TIMEFRAMES.get(req.timeframe)
    if not tf:
        raise HTTPException(400, "bad_timeframe")
    if req.duration_sec not in market.EXPIRY_CANDIDATES:
        raise HTTPException(400, "expiry_not_supported")
    if not (0 < req.stake <= 100_000) or not (0 < req.payout <= 2) or not (10 <= req.threshold <= 90):
        raise HTTPException(400, "bad_params")
    return tf


def _load_candles(dataset_id: int, tf: int):
    ds = storage.get_dataset(dataset_id)
    if not ds:
        raise HTTPException(404, "dataset_not_found")
    try:
        return ds, market.dataset_candles(ds, tf)
    except market.TimeframeUnsupported as e:
        raise HTTPException(422, f"timeframe_unsupported: {e.message}")


def public_settings() -> dict:
    out = {k: storage.get_setting(k) for k in ("mode", "halted", "stake", "auto_execute")}
    out["assets"] = storage.get_json("assets")
    out["po_expiries"] = storage.get_json("po_expiries")
    return out


# ---------- API ----------
@app.get("/health")
def health():
    return {"ok": True}


@app.get("/api/config")
def get_config(user=Depends(require_user)):
    return {
        "user": user["name"],
        "platform": market.status(),
        "timeframes": list(market.TIMEFRAMES.keys()),
        "expiry_candidates": market.EXPIRY_CANDIDATES,
        "providers": ai_providers.providers(),
        "modes": trading.available_modes(),
        "settings": public_settings(),
        "limits": {"max_stake": settings.MAX_STAKE, "daily_loss": settings.DAILY_LOSS_LIMIT,
                   "max_trades": settings.MAX_TRADES_PER_DAY},
        "news_connected": bool(settings.FINNHUB_API_KEY),
    }


@app.post("/api/signal")
async def get_signal(req: SignalReq, user=Depends(require_user)):
    enforce_heavy_limit(user)
    if req.symbol not in storage.get_json("assets"):
        raise HTTPException(400, "unknown_symbol")
    tf = market.TIMEFRAMES.get(req.timeframe)
    if not tf:
        raise HTTPException(400, "bad_timeframe")
    if req.duration_sec not in market.EXPIRY_CANDIDATES:
        raise HTTPException(400, "expiry_not_supported")
    if req.duration_sec not in storage.get_json("po_expiries"):
        raise HTTPException(400, "expiry_not_confirmed")
    if not ai_providers.is_connected(req.model):
        raise HTTPException(400, "model_not_connected")

    # Données Pocket Option : sans accès autorisé -> refus, AUCUN signal
    try:
        got = await market.feed.get_candles_tf(req.symbol, tf)
        candles, data_info = got["candles"], got["data"]
        result = engine.analyze(candles, tf, req.duration_sec, "rise_fall")
    except market.PlatformNotConnected as e:
        raise HTTPException(503, f"po_not_connected: {e}")
    except market.TimeframeUnsupported as e:
        raise HTTPException(422, f"timeframe_unsupported: {e.message}")
    except engine.DataError as e:
        raise HTTPException(422, f"{e.code}: {e.message}")

    ai_note = None
    if req.model != "technical" and result["direction"] != "NO_TRADE":
        try:
            rev = await ai_providers.review(req.model, req.symbol, req.timeframe,
                                            market.fmt_seconds(req.duration_sec), result, req.lang)
            ai_note = rev["note"]
            if rev["verdict"] == "DISAGREE":
                result["direction"] = result["action"] = "NO_TRADE"
                result["reasons"].append({"key": "ai_disagree"})
            else:
                result["reasons"].append({"key": "ai_agree"})
        except Exception as e:
            storage.log("error", f"IA {req.model} : {e}")
            raise HTTPException(502, f"ai_error: {e}")

    conf = storage.calibrated_confidence(result["score"]) if result["direction"] != "NO_TRADE" else {"value": None, "n": 0}
    now = int(time.time())
    mode = storage.get_setting("mode")
    sig = {
        "symbol": req.symbol, "market": "otc" if market.is_otc(req.symbol) else "real",
        "timeframe": req.timeframe, "duration_sec": req.duration_sec, "data_source": data_info.get("source"),
        "direction": result["direction"], "action": result["action"], "score": result["score"],
        "confidence": conf["value"], "confidence_n": conf["n"], "price": result["price"],
        "entry_epoch": now, "expiry_epoch": now + req.duration_sec, "model": req.model,
        "ai_note": ai_note, "reasons": result["reasons"], "mode": mode,
    }
    sid = storage.insert_signal(sig)
    out = {**sig, "id": sid, "data_epoch": result["data_epoch"], "indicators": result["indicators"],
           "confidence_ci": conf.get("ci"), "execution": None, "data_status": {"available": True, **data_info}}
    if storage.get_setting("auto_execute") == "1" and mode != "analysis":
        try:
            out["execution"] = await trading.execute(sig, sid, mode, float(storage.get_setting("stake")))
        except trading.TradeRejected as e:
            out["execution"] = {"status": "rejected", "message": str(e)}
    return out


@app.post("/api/execute")
async def execute(req: ExecuteReq, user=Depends(require_user)):
    sig = next((s for s in storage.list_signals(500) if s["id"] == req.signal_id), None)
    if not sig:
        raise HTTPException(404, "signal_not_found")
    if time.time() - sig["created_at"] > 10:
        raise HTTPException(409, "signal_too_old")
    try:
        return await trading.execute(sig, sig["id"], storage.get_setting("mode"),
                                     float(storage.get_setting("stake")), req.confirm_real)
    except trading.TradeRejected as e:
        raise HTTPException(400, str(e))


@app.get("/api/history")
def history(user=Depends(require_user)):
    return {"signals": storage.list_signals(100), "trades": storage.list_trades(100)}


@app.get("/api/stats")
def stats(user=Depends(require_user)):
    return {**storage.stats(), "simulation": storage.sim_stats()}


@app.post("/api/settings")
def update_settings(req: SettingsReq, user=Depends(require_user)):
    if req.mode is not None:
        if req.mode not in trading.MODES:
            raise HTTPException(400, "bad_mode")
        if not trading.available_modes().get(req.mode):
            raise HTTPException(400, "mode_unavailable")
        storage.set_setting("mode", req.mode)
    if req.stake is not None:
        if req.stake <= 0 or req.stake > settings.MAX_STAKE:
            raise HTTPException(400, "bad_stake")
        storage.set_setting("stake", req.stake)
    if req.auto_execute is not None:
        storage.set_setting("auto_execute", "1" if req.auto_execute else "0")
    if req.assets is not None:
        clean = [a.strip()[:40] for a in req.assets if a.strip()][:100]
        if not clean:
            raise HTTPException(400, "assets_empty")
        storage.set_setting("assets", json.dumps(clean))
    if req.po_expiries is not None:
        storage.set_setting("po_expiries", json.dumps(sorted(
            {d for d in req.po_expiries if d in market.EXPIRY_CANDIDATES})))
    return public_settings()


@app.post("/api/halt")
def halt(req: HaltReq, user=Depends(require_user)):
    storage.set_setting("halted", "1" if req.halted else "0")
    if req.halted:
        storage.set_setting("auto_execute", "0")
        storage.log("warning", f"ARRÊT D'URGENCE activé par {user['id']}")
    return {"halted": req.halted}


# ---------- Données importées, backtest et simulation (rejeu) ----------
@app.post("/api/datasets")
def create_dataset(req: DatasetReq, user=Depends(require_user)):
    enforce_heavy_limit(user)
    if len(req.csv) > MAX_CSV_CHARS:
        raise HTTPException(400, "csv_too_large")
    try:
        parsed = market.parse_csv_auto(req.csv)
    except market.DataFormatError as e:
        raise HTTPException(422, f"csv_invalid: {e}")
    name = (req.name.strip() or "Données importées")[:60]
    did = storage.insert_dataset(name, req.label.strip()[:80], parsed)
    return {"id": did, "name": name, "kind": parsed["kind"], "count": parsed["count"], "base_tf": parsed["base_tf"],
            "start": parsed["start"], "end": parsed["end"], "timeframes": parsed["timeframes"]}


@app.get("/api/datasets")
def datasets(user=Depends(require_user)):
    return storage.list_datasets()


@app.delete("/api/datasets/{did}")
def remove_dataset(did: int, user=Depends(require_user)):
    storage.delete_dataset(did)
    return {"ok": True}


@app.post("/api/backtest")
def backtest(req: BacktestReq, user=Depends(require_user)):
    """Backtest sur des données IMPORTÉES. Ce ne sont pas des prix Pocket Option,
    sauf si l'utilisateur les a lui-même relevés sur Pocket Option."""
    enforce_heavy_limit(user)
    tf = _check_test_params(req)
    ds, candles = _load_candles(req.dataset_id, tf)
    try:
        res = engine.backtest(candles, tf, req.duration_sec, req.stake, req.payout, req.threshold)
    except engine.DataError as e:
        raise HTTPException(422, f"{e.code}: {e.message}")
    res.update({"ci": storage.wilson(res["wins"], res["wins"] + res["losses"]), "candles": len(candles),
                "from": candles[0]["epoch"] if candles else None, "to": candles[-1]["epoch"] if candles else None,
                "timeframe": req.timeframe, "duration_sec": req.duration_sec, "threshold": req.threshold,
                "dataset": {"id": ds["id"], "name": ds["name"], "label": ds["label"]}, "source": "import"})
    return res


def _replay_view(rid: int) -> dict:
    rp = storage.get_replay(rid)
    if not rp:
        raise HTTPException(404, "replay_not_found")
    ds = storage.get_dataset(rp["dataset_id"])
    total = len(market.dataset_candles(ds, market.TIMEFRAMES[rp["timeframe"]])) if ds else 0
    return {**rp, "dataset_name": ds["name"] if ds else "?", "total_candles": total,
            "summary": storage.replay_summary(rid), "trades": storage.replay_trades(rid, 30),
            "label": "SIMULATION sur données importées — aucun ordre Pocket Option"}


@app.post("/api/replay/start")
def replay_start(req: ReplayStartReq, user=Depends(require_user)):
    tf = _check_test_params(req)
    _, candles = _load_candles(req.dataset_id, tf)
    try:
        engine.steps_for(tf, req.duration_sec)
    except engine.DataError as e:
        raise HTTPException(422, f"{e.code}: {e.message}")
    if len(candles) < engine.WARMUP + 2:
        raise HTTPException(422, "insufficient_data: pas assez de bougies pour ce timeframe")
    if not (0 < req.start_balance <= 10_000_000):
        raise HTTPException(400, "bad_params")
    rid = storage.create_replay({**req.model_dump(), "cursor": engine.WARMUP})
    return _replay_view(rid)


@app.post("/api/replay/{rid}/step")
def replay_step(rid: int, req: ReplayStepReq, user=Depends(require_user)):
    if storage.get_setting("halted") == "1":
        raise HTTPException(423, "halted")
    rp = storage.get_replay(rid)
    if not rp:
        raise HTTPException(404, "replay_not_found")
    if rp["finished"]:
        return _replay_view(rid)
    n = max(1, min(req.n, 500))
    tf = market.TIMEFRAMES[rp["timeframe"]]
    _, candles = _load_candles(rp["dataset_id"], tf)
    # n = nombre de TRADES à jouer (les NO TRADE intermédiaires sont comptés mais ne consomment pas d'étape)
    events, nxt = engine.simulate(candles, tf, rp["duration_sec"], start=rp["cursor"], max_trades=n,
                                  max_events=20_000, stake=rp["stake"], payout=rp["payout"],
                                  threshold=rp["threshold"])
    finished = nxt + engine.steps_for(tf, rp["duration_sec"]) - 1 >= len(candles)
    storage.save_replay_events(rid, events, nxt, finished)
    out = _replay_view(rid)
    out["last_events"] = events[-n:]
    return out


@app.get("/api/replay/{rid}")
def replay_get(rid: int, user=Depends(require_user)):
    return _replay_view(rid)


@app.get("/api/replays")
def replays(user=Depends(require_user)):
    return storage.list_replays()


# ---------- Telegram ----------
@app.post("/telegram/webhook")
async def telegram_webhook(request: Request, x_telegram_bot_api_secret_token: str = Header(default="")):
    if not telegram_bot.check_secret(x_telegram_bot_api_secret_token):
        raise HTTPException(403, "forbidden")
    try:
        await telegram_bot.handle_update(await request.json())
    except Exception as e:
        storage.log("error", f"Telegram : {e}")
    return {"ok": True}   # toujours 200 pour que Telegram ne renvoie pas la mise à jour en boucle


@app.get("/api/telegram")
async def telegram_info(user=Depends(require_user)):
    return await telegram_bot.info()


@app.post("/api/telegram/setup")
async def telegram_setup(user=Depends(require_user)):
    try:
        return await telegram_bot.setup()
    except Exception as e:
        raise HTTPException(400, f"telegram_error: {e}")


_news_cache = {"t": 0, "items": []}


@app.get("/api/news")
async def news(user=Depends(require_user)):
    if not settings.FINNHUB_API_KEY:
        return {"connected": False, "items": []}
    if time.time() - _news_cache["t"] > 300:
        try:
            async with httpx.AsyncClient(timeout=15) as c:
                r = await c.get("https://finnhub.io/api/v1/news",
                                params={"category": "forex", "token": settings.FINNHUB_API_KEY})
                r.raise_for_status()
                _news_cache["items"] = [
                    {"headline": n.get("headline"), "source": n.get("source"),
                     "url": n.get("url"), "datetime": n.get("datetime")} for n in r.json()[:30]]
                _news_cache["t"] = time.time()
        except Exception as e:
            storage.log("error", f"Actualités : {e}")
            raise HTTPException(503, "news_unavailable")
    return {"connected": True, "items": _news_cache["items"]}


@app.get("/api/logs")
def logs(user=Depends(require_user)):
    return storage.recent_logs()


app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
def index():
    return FileResponse("static/index.html")
