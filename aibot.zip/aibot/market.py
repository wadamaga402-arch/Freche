"""Plateforme cible : POCKET OPTION.

Vérification (octobre 2026) : Pocket Option ne propose PAS d'API officielle publique
(son propre blog l'indique). Les bibliothèques trouvées sur GitHub sont non officielles et
demandent de copier la session privée du navigateur : elles ne sont PAS utilisées ici.

Conséquence : aucune donnée de prix Pocket Option (ni OTC, ni marché réel) n'est disponible
pour ce projet. Ce module expose donc un état « non connecté » et refuse de fournir des prix.
Aucun prix d'une autre plateforme n'est substitué aux prix Pocket Option.

Si Pocket Option publie un jour un accès officiel, il suffira d'implémenter
`PocketOptionFeed.get_candles_tf` (et l'exécuteur dans trading.py) sans toucher au reste."""
import csv
import io
from typing import Dict, List

PLATFORM = "Pocket Option"

# Timeframes d'ANALYSE demandés (taille d'une bougie, en secondes).
TIMEFRAMES = {"5s": 5, "10s": 10, "15s": 15, "1m": 60}

# Durées d'EXPIRATION demandées. Sans accès officiel, l'application ne peut pas vérifier
# lesquelles Pocket Option propose : l'utilisateur coche dans Réglages celles qu'il voit
# réellement dans son terminal (information « déclarée par l'utilisateur »).
EXPIRY_CANDIDATES = [5, 10, 15, 60]

# Liste INDICATIVE d'actifs (non vérifiable automatiquement sans accès à la plateforme).
# Modifiable dans Réglages pour correspondre à ce que montre votre terminal.
DEFAULT_ASSETS = [
    "EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "EUR/JPY",
    "EUR/USD OTC", "GBP/USD OTC", "USD/JPY OTC", "AUD/CAD OTC", "EUR/GBP OTC",
    "Bitcoin OTC", "Gold OTC",
]

MIN_CANDLES = 60
MAX_EMPTY_RATIO = 0.20


def fmt_seconds(sec: int) -> str:
    if sec % 3600 == 0:
        return f"{sec // 3600}h"
    if sec % 60 == 0:
        return f"{sec // 60}m"
    return f"{sec}s"


def is_otc(asset: str) -> bool:
    return asset.upper().endswith("OTC")


class PlatformNotConnected(Exception):
    """Aucun accès autorisé à la plateforme : pas de données, pas d'ordres."""


class TimeframeUnsupported(Exception):
    def __init__(self, message: str, details: Dict = None):
        super().__init__(message)
        self.message = message
        self.details = details or {}


class DataFormatError(Exception):
    pass


NOT_CONNECTED_MSG = ("Pocket Option ne fournit pas d'API officielle : les prix Pocket Option "
                     "(dont OTC) ne sont pas connectés. Aucun signal ne peut être calculé.")


class PocketOptionFeed:
    connected = False
    data_reason = NOT_CONNECTED_MSG
    execution_reason = ("Aucun moyen officiel d'envoyer des ordres à Pocket Option : "
                        "l'exécution automatique est désactivée.")

    async def get_candles_tf(self, asset: str, tf: int, count: int = 200) -> Dict:
        raise PlatformNotConnected(self.data_reason)

    async def get_price_at(self, asset: str, epoch: int) -> Dict:
        raise PlatformNotConnected(self.data_reason)


feed = PocketOptionFeed()


def status() -> Dict:
    return {
        "platform": PLATFORM,
        "data_connected": feed.connected,
        "execution_connected": False,
        "data_reason": feed.data_reason,
        "execution_reason": feed.execution_reason,
    }


# ---------- Outils génériques, prêts pour un futur flux officiel ----------
def candles_from_ticks(times: List[int], prices: List[float], tf: int) -> Dict:
    """Regroupe de VRAIS ticks en bougies de `tf` secondes, sans jamais créer de bougie
    pour une période sans tick. Refuse si les ticks sont trop espacés pour ce timeframe."""
    if len(times) < 2:
        raise TimeframeUnsupported("Pas assez de ticks.", {"ticks": len(times)})
    span = times[-1] - times[0]
    avg_interval = span / (len(times) - 1) if span > 0 else 0
    buckets: Dict[int, List[float]] = {}
    for t, p in zip(times, prices):
        buckets.setdefault(t - t % tf, []).append(p)
    first, last = min(buckets), max(buckets)
    expected = (last - first) // tf + 1
    empty_ratio = 1 - len(buckets) / expected if expected else 1
    details = {"ticks": len(times), "avg_tick_interval_s": round(avg_interval, 2),
               "candles": len(buckets), "empty_ratio": round(empty_ratio, 3)}
    if avg_interval == 0 or avg_interval > tf / 2:
        raise TimeframeUnsupported(f"Ticks trop espacés pour des bougies de {tf} s.", details)
    if empty_ratio > MAX_EMPTY_RATIO:
        raise TimeframeUnsupported(f"Trop de périodes de {tf} s sans aucun tick.", details)
    candles = [{"epoch": s, "open": buckets[s][0], "high": max(buckets[s]), "low": min(buckets[s]),
                "close": buckets[s][-1]} for s in sorted(buckets)]
    return {"candles": candles, "details": details}


MAX_ROWS = 100_000


def _parse_time(txt: str) -> int:
    txt = txt.strip()
    try:
        v = float(txt)
        return int(v / 1000) if v > 1e11 else int(v)   # millisecondes ou secondes
    except ValueError:
        pass
    from datetime import datetime, timezone
    try:
        d = datetime.fromisoformat(txt.replace("Z", "+00:00").replace("/", "-"))
    except ValueError:
        raise DataFormatError(f"Date/heure illisible : {txt[:30]}")
    if d.tzinfo is None:
        d = d.replace(tzinfo=timezone.utc)
    return int(d.timestamp())


def _num(txt: str, comma_decimal: bool) -> float:
    txt = txt.strip()
    if comma_decimal:
        txt = txt.replace(" ", "").replace(",", ".")
    return float(txt)


def parse_csv_auto(text: str) -> Dict:
    """Lit un fichier importé par l'utilisateur. Formats acceptés (en-tête facultatif) :
      - bougies : temps,open,high,low,close[,volume]
      - ticks   : temps,prix
    temps = secondes ou millisecondes Unix, ou date ISO (2026-10-17 14:30:05, UTC si pas de fuseau).
    Séparateur « , » ou « ; » (avec « ; », la virgule décimale est acceptée).
    Rien n'est complété ni inventé : les lignes doivent être cohérentes, sinon erreur."""
    text = text.strip().lstrip("\ufeff")
    if not text:
        raise DataFormatError("Fichier vide.")
    first = text.splitlines()[0]
    delim = ";" if first.count(";") >= first.count(",") and ";" in first else ("\t" if "\t" in first else ",")
    comma_dec = delim != ","
    rows, kind = [], None
    for n, line in enumerate(csv.reader(io.StringIO(text), delimiter=delim), start=1):
        line = [x for x in line if x.strip() != ""]
        if not line:
            continue
        if n > MAX_ROWS + 1:
            raise DataFormatError(f"Fichier trop long (maximum {MAX_ROWS} lignes).")
        try:
            ep = _parse_time(line[0])
            vals = [_num(x, comma_dec) for x in line[1:5]]
        except (DataFormatError, ValueError):
            if not rows and n == 1:
                continue  # en-tête
            raise DataFormatError(f"Ligne {n} invalide : {delim.join(line)[:60]}")
        k = "candles" if len(vals) >= 4 else ("ticks" if len(vals) == 1 else None)
        if k is None:
            raise DataFormatError(f"Ligne {n} : il faut 2 colonnes (ticks) ou 5 colonnes (bougies).")
        if kind and k != kind:
            raise DataFormatError(f"Ligne {n} : mélange de ticks et de bougies.")
        kind = k
        if any(v <= 0 for v in vals):
            raise DataFormatError(f"Ligne {n} : prix nul ou négatif.")
        if kind == "candles":
            o, h, l, c = vals[:4]
            if not (l <= min(o, c) and h >= max(o, c)):
                raise DataFormatError(f"Ligne {n} : bougie incohérente (high/low).")
            rows.append({"epoch": ep, "open": o, "high": h, "low": l, "close": c})
        else:
            rows.append({"epoch": ep, "price": vals[0]})
    if not rows:
        raise DataFormatError("Aucune ligne de données.")
    rows.sort(key=lambda r: r["epoch"])  # tri stable : l'ordre des ticks d'une même seconde est conservé
    if kind == "candles":
        dedup = {}
        for r in rows:
            if r["epoch"] in dedup and dedup[r["epoch"]] != r:
                raise DataFormatError(f"Deux bougies différentes à la même heure ({r['epoch']}).")
            dedup[r["epoch"]] = r
        rows = list(dedup.values())
        base_tf = infer_timeframe(rows)
    else:
        base_tf = None
    out = {"kind": kind, "rows": rows, "base_tf": base_tf, "count": len(rows),
           "start": rows[0]["epoch"], "end": rows[-1]["epoch"]}
    out["timeframes"] = available_timeframes(out)
    if not out["timeframes"]:
        raise DataFormatError("Données insuffisantes ou trop espacées pour 5s, 10s, 15s ou 1m "
                              f"(il faut au moins {MIN_CANDLES + 20} bougies exploitables).")
    return out


def infer_timeframe(candles: List[Dict]) -> int:
    if len(candles) < 3:
        raise DataFormatError("Pas assez de bougies.")
    gaps = [b["epoch"] - a["epoch"] for a, b in zip(candles, candles[1:])]
    base = max(set(gaps), key=gaps.count)
    if base not in TIMEFRAMES.values():
        raise DataFormatError(f"Intervalle entre bougies = {base} s : seuls 5s, 10s, 15s et 1m sont gérés.")
    if any(g % base for g in gaps):
        raise DataFormatError("Intervalles irréguliers entre bougies (pas un multiple du timeframe).")
    holes = sum(1 for g in gaps if g != base)
    if holes / len(gaps) > 0.05:
        raise DataFormatError(f"Trop de trous dans les données ({holes} sur {len(gaps)}).")
    return base


def aggregate_candles(candles: List[Dict], base_tf: int, tf: int) -> List[Dict]:
    """Regroupe des bougies réelles en bougies plus longues (ex. 5s -> 15s).
    Seules les périodes COMPLÈTES sont gardées. Jamais l'inverse (pas de 1m -> 5s)."""
    if tf == base_tf:
        return candles
    if tf < base_tf or tf % base_tf:
        raise TimeframeUnsupported(f"Impossible d'obtenir des bougies de {fmt_seconds(tf)} à partir de bougies de "
                                   f"{fmt_seconds(base_tf)} sans inventer de données.")
    need = tf // base_tf
    groups: Dict[int, List[Dict]] = {}
    for c in candles:
        groups.setdefault(c["epoch"] - c["epoch"] % tf, []).append(c)
    out = []
    for start in sorted(groups):
        g = groups[start]
        if len(g) != need:
            continue
        out.append({"epoch": start, "open": g[0]["open"], "high": max(x["high"] for x in g),
                    "low": min(x["low"] for x in g), "close": g[-1]["close"]})
    return out


def dataset_candles(ds: Dict, tf: int) -> List[Dict]:
    if ds["kind"] == "ticks":
        built = candles_from_ticks([r["epoch"] for r in ds["rows"]], [r["price"] for r in ds["rows"]], tf)
        return built["candles"]
    return aggregate_candles(ds["rows"], ds["base_tf"], tf)


def available_timeframes(ds: Dict) -> List[str]:
    ok = []
    for name, tf in TIMEFRAMES.items():
        try:
            if len(dataset_candles(ds, tf)) >= MIN_CANDLES + 20:
                ok.append(name)
        except (TimeframeUnsupported, DataFormatError):
            pass
    return ok
