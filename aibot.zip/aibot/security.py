"""Authentification (Telegram Mini App ou clé d'accès) et limitation des requêtes."""
import hashlib
import hmac
import json
import time
from collections import defaultdict, deque
from typing import Optional
from urllib.parse import parse_qsl

from fastapi import Header, HTTPException, Request

from config import settings


def verify_telegram_init_data(init_data: str, bot_token: str, max_age: int = 86400) -> Optional[dict]:
    """Vérifie la signature officielle Telegram (HMAC-SHA256) des données initData."""
    if not init_data or not bot_token:
        return None
    pairs = dict(parse_qsl(init_data, keep_blank_values=True))
    received = pairs.pop("hash", None)
    if not received:
        return None
    check = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
    secret = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
    expected = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, received):
        return None
    if time.time() - int(pairs.get("auth_date", 0)) > max_age:
        return None
    try:
        return json.loads(pairs.get("user", "{}"))
    except json.JSONDecodeError:
        return None


class RateLimiter:
    def __init__(self, per_minute: int):
        self.per_minute = per_minute
        self.hits = defaultdict(deque)

    def check(self, key: str) -> bool:
        now = time.time()
        q = self.hits[key]
        while q and now - q[0] > 60:
            q.popleft()
        if len(q) >= self.per_minute:
            return False
        q.append(now)
        return True


limiter = RateLimiter(settings.RATE_LIMIT_PER_MIN)


async def require_user(request: Request,
                       x_telegram_init_data: str = Header(default=""),
                       x_access_key: str = Header(default="")) -> dict:
    user = None
    if x_telegram_init_data:
        tg = verify_telegram_init_data(x_telegram_init_data, settings.TELEGRAM_BOT_TOKEN)
        # Sécurité par défaut : liste vide = aucun compte Telegram autorisé
        if tg and str(tg.get("id")) in settings.ALLOWED_TELEGRAM_IDS:
            user = {"id": f"tg:{tg.get('id')}", "name": tg.get("first_name", "")}
    if not user and settings.ACCESS_KEY and x_access_key and hmac.compare_digest(x_access_key, settings.ACCESS_KEY):
        user = {"id": "key", "name": "Admin"}
    if not user:
        raise HTTPException(status_code=401, detail="unauthorized")
    # limite large pour toutes les requêtes (lecture), stricte pour les analyses (voir main.py)
    if not general_limiter.check(user["id"]):
        raise HTTPException(status_code=429, detail="rate_limited")
    return user


general_limiter = RateLimiter(120)


def enforce_heavy_limit(user: dict) -> None:
    if not limiter.check(user["id"]):
        raise HTTPException(status_code=429, detail="rate_limited")
