// ===== AI Signal Bot — Pocket Option (aucun secret ici) =====
const tg = window.Telegram && window.Telegram.WebApp;
if (tg) { try { tg.ready(); tg.expand(); } catch (e) {} }

const store = {
  get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} },
};

const I18N = {
  fr: {
    login_title: "Connexion", login_help: "Hors de Telegram, entrez la clé d'accès définie sur le serveur (ACCESS_KEY).",
    login_btn: "Se connecter", asset: "ACTIF", model: "MODÈLE IA",
    timeframe: "TIMEFRAME", timeframe_hint: "(bougies analysées)", expiry_label: "DURÉE DU TRADE", expiry_hint: "(expiration Pocket Option)",
    analyze_btn: "ANALYSER LE MARCHÉ",
    indicative: "Signaux indicatifs. Aucun résultat n'est garanti. Le trading comporte un risque de perte.",
    st_title: "État de la connexion Pocket Option", st_data: "Données de prix (dont OTC)", st_exec: "Exécution des ordres",
    st_off: "Non connecté", st_on: "Connecté",
    st_explain: "Pocket Option ne propose pas d'API officielle. Sans source de prix autorisée, le moteur ne peut pas calculer de signal : l'appli l'affiche au lieu d'inventer un résultat.",
    otc_note: "Actif OTC : cours propres à Pocket Option, disponibles uniquement chez Pocket Option.",
    real_note: "Actif de marché réel tel que listé chez Pocket Option.",
    exp_note_none: "Aucune durée confirmée. Dans Réglages, cochez les durées que vous voyez dans votre terminal Pocket Option.",
    exp_note: "Durées barrées : non confirmées dans votre terminal Pocket Option (à cocher dans Réglages).",
    p1: "Demande des données Pocket Option…", p2: "Vérification de la connexion…", p3: "Analyse…", p4: "Relecture IA…",
    direction: "Direction", tf_used: "Timeframe", exp_used: "Durée prévue", sig_time: "Heure du signal", expiry: "Expiration",
    price: "Prix d'entrée", score: "Score technique", conf: "Confiance calibrée",
    conf_none: "Non calibrée ({n} résultats vérifiés, minimum 30)", reasons: "Raisons techniques", ai_note: "Avis IA",
    data_status: "État des données", data_ok: "Disponibles", data_ko: "Indisponibles", unavailable_title: "Aucun signal",
    no_trade_btn: "NO TRADE — conditions insuffisantes, ne pas entrer", exec_btn: "Exécuter cet ordre", choose_expiry: "Choisissez une durée de trade confirmée.",
    tab_signal: "Signal", tab_history: "Historique", tab_stats: "Stats", tab_info: "Infos", tab_settings: "Réglages",
    no_history: "Aucun signal pour l'instant.", total: "Signaux", won: "Gagnés", lost: "Perdus", winrate: "Taux de réussite vérifié",
    samples: "échantillons", ci: "Intervalle de confiance 95 %", by_asset: "Par actif", by_tf: "Par timeframe", by_dur: "Par durée",
    pending: "En attente", no_trade: "NO TRADE", small_sample: "Échantillon trop petit pour conclure (moins de 30).",
    sim_balance: "Solde simulé", by_mode: "Ordres par mode",
    backtest_title: "Test sur données historiques (fichier importé)",
    backtest_help: "Importez un CSV « epoch,open,high,low,close » au timeframe choisi sur l'écran Signal. Ce ne sont PAS des prix Pocket Option, sauf si vous les avez enregistrés vous-même. Résultats séparés de vos résultats réels.",
    bt_label: "Origine des données (ex. : relevé manuel EUR/USD OTC)", backtest_run: "Lancer le test", bt_trades: "Trades testés",
    bt_need_file: "Choisissez d'abord un fichier CSV.", bt_source: "Source : fichier importé",
    news: "Actualités", lessons: "Leçons", news_off: "Non connecté (ajoutez FINNHUB_API_KEY sur le serveur).",
    halt_on: "🛑 ARRÊT D'URGENCE", halt_off: "▶️ Désactiver l'arrêt d'urgence", halt_help: "Bloque tout nouvel ordre, la simulation pas à pas et l'exécution automatique.",
    po_setup: "Configuration Pocket Option", po_expiries: "Durées visibles dans VOTRE terminal Pocket Option",
    po_expiries_help: "L'application ne peut pas lire Pocket Option : cochez uniquement les durées que vous voyez réellement sur la plateforme.",
    po_assets: "Actifs (un par ligne, comme écrits chez Pocket Option)",
    po_assets_help: "Liste indicative à ajuster selon votre terminal. Ajoutez « OTC » à la fin pour les actifs OTC.",
    exec_mode: "Mode d'exécution", stake: "Mise par ordre", auto_exec: "Exécuter automatiquement chaque signal", save: "Enregistrer",
    mode_analysis: "Analyse seulement", mode_simulation: "Simulation (virtuel)", mode_demo: "Démo Pocket Option", mode_real: "Réel Pocket Option",
    unavailable: "indisponible", mode_note: "Démo et réel : pas d'API officielle Pocket Option. Simulation : nécessite une source de prix autorisée pour vérifier les résultats.",
    ai_models: "Modèles IA", connected: "Connecté", not_connected: "Non connecté", integrations: "Intégrations",
    po_note: "Vérification : Pocket Option indique ne pas offrir d'accès API direct. Les bibliothèques non officielles demandent de copier votre session de navigateur : elles ne sont pas utilisées. Aucun prix d'une autre plateforme n'est présenté comme un prix Pocket Option. Dès qu'un accès officiel existera, il pourra être branché sans changer l'interface.",
    saved: "Enregistré.", limits: "Limites serveur : mise max {s}, perte max/jour {l}, {t} trades/jour.",
    err_unauthorized: "Accès refusé. Vérifiez la clé ou l'ID Telegram autorisé.", err_rate_limited: "Trop de requêtes, patientez une minute.",
    err_po_not_connected: "Données Pocket Option non connectées : aucun signal généré.",
    err_timeframe_unsupported: "Timeframe non pris en charge par la source connectée. Aucun signal généré.",
    err_expiry_not_confirmed: "Durée non confirmée dans votre terminal Pocket Option (voir Réglages).",
    err_expiry_not_supported: "Durée d'expiration non proposée.", err_bad_timeframe: "Timeframe invalide.",
    err_unknown_symbol: "Actif inconnu.", err_model_not_connected: "Ce modèle n'est pas connecté.",
    err_ai_error: "Le modèle IA n'a pas répondu. Aucun signal généré.", err_stale_data: "Données trop anciennes. Aucun signal généré.",
    err_insufficient_data: "Pas assez de données. Aucun signal généré.", err_csv_invalid: "Fichier CSV invalide",
    err_backtest_mismatch: "La durée doit être un multiple du timeframe (ex. 5s → 15s, 15s → 1m).",
    err_mode_unavailable: "Ce mode n'est pas disponible sans accès officiel à Pocket Option.",
    err_signal_too_old: "Signal trop ancien : relancez une analyse.", err_generic: "Erreur",
    r_trend_up: "Tendance haussière (EMA 9 > 21 > 50)", r_trend_down: "Tendance baissière (EMA 9 < 21 < 50)",
    r_trend_mixed: "Tendance indécise", r_rsi_overbought: "RSI suracheté ({rsi})", r_rsi_oversold: "RSI survendu ({rsi})",
    r_rsi_bull: "RSI haussier ({rsi})", r_rsi_bear: "RSI baissier ({rsi})", r_rsi_neutral: "RSI neutre ({rsi})",
    r_momentum_up: "Momentum haussier fort (> 1 ATR)", r_momentum_down: "Momentum baissier fort (> 1 ATR)",
    r_pattern: "Figure de chandelier : {name}", r_near_resistance: "Prix proche d'une résistance ({level})",
    r_near_support: "Prix proche d'un support ({level})", r_vol_spike: "Pic de volatilité anormal", r_vol_flat: "Marché trop plat",
    r_no_volume: "Volume non disponible", r_no_calendar: "Calendrier économique non connecté",
    r_horizon_short: "Expiration plus courte qu'une bougie", r_horizon_long: "Expiration très longue par rapport au timeframe",
    r_ai_agree: "L'IA confirme l'analyse", r_ai_disagree: "L'IA rejette le signal → NO TRADE",
  },
  en: {
    login_title: "Sign in", login_help: "Outside Telegram, enter the access key set on the server (ACCESS_KEY).",
    login_btn: "Sign in", asset: "ASSET", model: "AI MODEL",
    timeframe: "TIMEFRAME", timeframe_hint: "(analysed candles)", expiry_label: "TRADE DURATION", expiry_hint: "(Pocket Option expiry)",
    analyze_btn: "ANALYSE THE MARKET",
    indicative: "Indicative signals. No result is guaranteed. Trading involves risk of loss.",
    st_title: "Pocket Option connection status", st_data: "Price data (incl. OTC)", st_exec: "Order execution",
    st_off: "Not connected", st_on: "Connected",
    st_explain: "Pocket Option offers no official API. Without an authorised price source the engine cannot compute a signal: the app says so instead of inventing a result.",
    otc_note: "OTC asset: Pocket Option's own prices, only available on Pocket Option.",
    real_note: "Real-market asset as listed on Pocket Option.",
    exp_note_none: "No confirmed duration. In Settings, tick the durations you see in your Pocket Option terminal.",
    exp_note: "Struck-through durations: not confirmed in your Pocket Option terminal (tick them in Settings).",
    p1: "Requesting Pocket Option data…", p2: "Checking connection…", p3: "Analysing…", p4: "AI review…",
    direction: "Direction", tf_used: "Timeframe", exp_used: "Planned duration", sig_time: "Signal time", expiry: "Expiry",
    price: "Entry price", score: "Technical score", conf: "Calibrated confidence",
    conf_none: "Not calibrated ({n} verified results, minimum 30)", reasons: "Technical reasons", ai_note: "AI opinion",
    data_status: "Data status", data_ok: "Available", data_ko: "Unavailable", unavailable_title: "No signal",
    no_trade_btn: "NO TRADE — insufficient conditions, stay out", exec_btn: "Execute this order", choose_expiry: "Choose a confirmed trade duration.",
    tab_signal: "Signal", tab_history: "History", tab_stats: "Stats", tab_info: "Info", tab_settings: "Settings",
    no_history: "No signals yet.", total: "Signals", won: "Won", lost: "Lost", winrate: "Verified win rate",
    samples: "samples", ci: "95% confidence interval", by_asset: "By asset", by_tf: "By timeframe", by_dur: "By duration",
    pending: "Pending", no_trade: "NO TRADE", small_sample: "Sample too small to conclude (under 30).",
    sim_balance: "Simulated balance", by_mode: "Orders by mode",
    backtest_title: "Historical data test (imported file)",
    backtest_help: "Import an \"epoch,open,high,low,close\" CSV at the timeframe chosen on the Signal screen. These are NOT Pocket Option prices unless you recorded them yourself. Kept separate from real results.",
    bt_label: "Data origin (e.g. manual record EUR/USD OTC)", backtest_run: "Run test", bt_trades: "Tested trades",
    bt_need_file: "Choose a CSV file first.", bt_source: "Source: imported file",
    news: "News", lessons: "Lessons", news_off: "Not connected (add FINNHUB_API_KEY on the server).",
    halt_on: "🛑 EMERGENCY STOP", halt_off: "▶️ Release emergency stop", halt_help: "Blocks any new order, the step-by-step simulation and auto-execution.",
    po_setup: "Pocket Option setup", po_expiries: "Durations visible in YOUR Pocket Option terminal",
    po_expiries_help: "The app cannot read Pocket Option: only tick the durations you actually see on the platform.",
    po_assets: "Assets (one per line, as written on Pocket Option)",
    po_assets_help: "Indicative list, adjust it to your terminal. Add \"OTC\" at the end for OTC assets.",
    exec_mode: "Execution mode", stake: "Stake per order", auto_exec: "Automatically execute each signal", save: "Save",
    mode_analysis: "Analysis only", mode_simulation: "Simulation (virtual)", mode_demo: "Pocket Option demo", mode_real: "Pocket Option real",
    unavailable: "unavailable", mode_note: "Demo and real: no official Pocket Option API. Simulation: needs an authorised price source to verify results.",
    ai_models: "AI models", connected: "Connected", not_connected: "Not connected", integrations: "Integrations",
    po_note: "Check: Pocket Option states it offers no direct API access. Unofficial libraries require copying your browser session and are not used. No other platform's price is presented as a Pocket Option price. If official access appears, it can be plugged in without changing the interface.",
    saved: "Saved.", limits: "Server limits: max stake {s}, max daily loss {l}, {t} trades/day.",
    err_unauthorized: "Access denied. Check the key or allowed Telegram ID.", err_rate_limited: "Too many requests, wait a minute.",
    err_po_not_connected: "Pocket Option data not connected: no signal generated.",
    err_timeframe_unsupported: "Timeframe not supported by the connected source. No signal generated.",
    err_expiry_not_confirmed: "Duration not confirmed in your Pocket Option terminal (see Settings).",
    err_expiry_not_supported: "Expiry not offered.", err_bad_timeframe: "Invalid timeframe.",
    err_unknown_symbol: "Unknown asset.", err_model_not_connected: "This model is not connected.",
    err_ai_error: "The AI model did not respond. No signal generated.", err_stale_data: "Data too old. No signal generated.",
    err_insufficient_data: "Not enough data. No signal generated.", err_csv_invalid: "Invalid CSV file",
    err_backtest_mismatch: "Duration must be a multiple of the timeframe (e.g. 5s → 15s, 15s → 1m).",
    err_mode_unavailable: "This mode is unavailable without official Pocket Option access.",
    err_signal_too_old: "Signal too old: run a new analysis.", err_generic: "Error",
    r_trend_up: "Uptrend (EMA 9 > 21 > 50)", r_trend_down: "Downtrend (EMA 9 < 21 < 50)", r_trend_mixed: "Unclear trend",
    r_rsi_overbought: "RSI overbought ({rsi})", r_rsi_oversold: "RSI oversold ({rsi})", r_rsi_bull: "Bullish RSI ({rsi})",
    r_rsi_bear: "Bearish RSI ({rsi})", r_rsi_neutral: "Neutral RSI ({rsi})", r_momentum_up: "Strong bullish momentum (> 1 ATR)",
    r_momentum_down: "Strong bearish momentum (> 1 ATR)", r_pattern: "Candle pattern: {name}",
    r_near_resistance: "Price near resistance ({level})", r_near_support: "Price near support ({level})",
    r_vol_spike: "Abnormal volatility spike", r_vol_flat: "Market too flat", r_no_volume: "Volume not available",
    r_no_calendar: "Economic calendar not connected", r_horizon_short: "Expiry shorter than one candle",
    r_horizon_long: "Expiry very long vs timeframe", r_ai_agree: "AI confirms the analysis", r_ai_disagree: "AI rejects the signal → NO TRADE",
  },
  es: {
    login_title: "Acceso", login_help: "Fuera de Telegram, introduce la clave de acceso definida en el servidor (ACCESS_KEY).",
    login_btn: "Entrar", asset: "ACTIVO", model: "MODELO IA",
    timeframe: "TIMEFRAME", timeframe_hint: "(velas analizadas)", expiry_label: "DURACIÓN", expiry_hint: "(vencimiento Pocket Option)",
    analyze_btn: "ANALIZAR EL MERCADO",
    indicative: "Señales indicativas. Ningún resultado está garantizado. El trading implica riesgo de pérdida.",
    st_title: "Estado de la conexión Pocket Option", st_data: "Datos de precios (incl. OTC)", st_exec: "Ejecución de órdenes",
    st_off: "No conectado", st_on: "Conectado",
    st_explain: "Pocket Option no ofrece API oficial. Sin una fuente de precios autorizada, el motor no puede calcular señales: la app lo indica en lugar de inventar un resultado.",
    otc_note: "Activo OTC: precios propios de Pocket Option, solo disponibles en Pocket Option.",
    real_note: "Activo de mercado real tal como aparece en Pocket Option.",
    exp_note_none: "Ninguna duración confirmada. En Ajustes, marca las duraciones que ves en tu terminal de Pocket Option.",
    exp_note: "Duraciones tachadas: no confirmadas en tu terminal de Pocket Option (márcalas en Ajustes).",
    p1: "Solicitando datos de Pocket Option…", p2: "Verificando conexión…", p3: "Analizando…", p4: "Revisión IA…",
    direction: "Dirección", tf_used: "Timeframe", exp_used: "Duración prevista", sig_time: "Hora de la señal", expiry: "Vencimiento",
    price: "Precio de entrada", score: "Puntuación técnica", conf: "Confianza calibrada",
    conf_none: "No calibrada ({n} resultados verificados, mínimo 30)", reasons: "Razones técnicas", ai_note: "Opinión IA",
    data_status: "Estado de los datos", data_ok: "Disponibles", data_ko: "No disponibles", unavailable_title: "Sin señal",
    no_trade_btn: "NO TRADE — condiciones insuficientes, no entrar", exec_btn: "Ejecutar esta orden", choose_expiry: "Elige una duración confirmada.",
    tab_signal: "Señal", tab_history: "Historial", tab_stats: "Estadísticas", tab_info: "Info", tab_settings: "Ajustes",
    no_history: "Aún no hay señales.", total: "Señales", won: "Ganadas", lost: "Perdidas", winrate: "Tasa de acierto verificada",
    samples: "muestras", ci: "Intervalo de confianza 95 %", by_asset: "Por activo", by_tf: "Por timeframe", by_dur: "Por duración",
    pending: "Pendiente", no_trade: "NO TRADE", small_sample: "Muestra demasiado pequeña para concluir (menos de 30).",
    sim_balance: "Saldo simulado", by_mode: "Órdenes por modo",
    backtest_title: "Prueba con datos históricos (archivo importado)",
    backtest_help: "Importa un CSV «epoch,open,high,low,close» al timeframe elegido en la pantalla Señal. NO son precios de Pocket Option salvo que los hayas registrado tú. Separado de los resultados reales.",
    bt_label: "Origen de los datos (ej.: registro manual EUR/USD OTC)", backtest_run: "Iniciar prueba", bt_trades: "Operaciones probadas",
    bt_need_file: "Elige primero un archivo CSV.", bt_source: "Fuente: archivo importado",
    news: "Noticias", lessons: "Lecciones", news_off: "No conectado (añade FINNHUB_API_KEY en el servidor).",
    halt_on: "🛑 PARADA DE EMERGENCIA", halt_off: "▶️ Desactivar parada", halt_help: "Bloquea cualquier nueva orden, la simulación paso a paso y la ejecución automática.",
    po_setup: "Configuración Pocket Option", po_expiries: "Duraciones visibles en TU terminal de Pocket Option",
    po_expiries_help: "La app no puede leer Pocket Option: marca solo las duraciones que realmente ves en la plataforma.",
    po_assets: "Activos (uno por línea, como aparecen en Pocket Option)",
    po_assets_help: "Lista indicativa, ajústala a tu terminal. Añade «OTC» al final para los activos OTC.",
    exec_mode: "Modo de ejecución", stake: "Importe por orden", auto_exec: "Ejecutar automáticamente cada señal", save: "Guardar",
    mode_analysis: "Solo análisis", mode_simulation: "Simulación (virtual)", mode_demo: "Demo Pocket Option", mode_real: "Real Pocket Option",
    unavailable: "no disponible", mode_note: "Demo y real: no hay API oficial de Pocket Option. Simulación: necesita una fuente de precios autorizada para verificar resultados.",
    ai_models: "Modelos IA", connected: "Conectado", not_connected: "No conectado", integrations: "Integraciones",
    po_note: "Verificación: Pocket Option indica que no ofrece acceso API directo. Las bibliotecas no oficiales piden copiar tu sesión del navegador y no se usan. Ningún precio de otra plataforma se presenta como precio de Pocket Option. Si aparece un acceso oficial, podrá conectarse sin cambiar la interfaz.",
    saved: "Guardado.", limits: "Límites del servidor: importe máx {s}, pérdida máx/día {l}, {t} operaciones/día.",
    err_unauthorized: "Acceso denegado. Revisa la clave o el ID de Telegram autorizado.", err_rate_limited: "Demasiadas solicitudes, espera un minuto.",
    err_po_not_connected: "Datos de Pocket Option no conectados: no se generó señal.",
    err_timeframe_unsupported: "Timeframe no soportado por la fuente conectada. No se generó señal.",
    err_expiry_not_confirmed: "Duración no confirmada en tu terminal de Pocket Option (ver Ajustes).",
    err_expiry_not_supported: "Vencimiento no ofrecido.", err_bad_timeframe: "Timeframe no válido.",
    err_unknown_symbol: "Activo desconocido.", err_model_not_connected: "Este modelo no está conectado.",
    err_ai_error: "El modelo IA no respondió. No se generó señal.", err_stale_data: "Datos demasiado antiguos. No se generó señal.",
    err_insufficient_data: "Datos insuficientes. No se generó señal.", err_csv_invalid: "Archivo CSV no válido",
    err_backtest_mismatch: "La duración debe ser múltiplo del timeframe (ej. 5s → 15s, 15s → 1m).",
    err_mode_unavailable: "Este modo no está disponible sin acceso oficial a Pocket Option.",
    err_signal_too_old: "Señal demasiado antigua: vuelve a analizar.", err_generic: "Error",
    r_trend_up: "Tendencia alcista (EMA 9 > 21 > 50)", r_trend_down: "Tendencia bajista (EMA 9 < 21 < 50)",
    r_trend_mixed: "Tendencia indecisa", r_rsi_overbought: "RSI sobrecomprado ({rsi})", r_rsi_oversold: "RSI sobrevendido ({rsi})",
    r_rsi_bull: "RSI alcista ({rsi})", r_rsi_bear: "RSI bajista ({rsi})", r_rsi_neutral: "RSI neutral ({rsi})",
    r_momentum_up: "Momentum alcista fuerte (> 1 ATR)", r_momentum_down: "Momentum bajista fuerte (> 1 ATR)",
    r_pattern: "Patrón de vela: {name}", r_near_resistance: "Precio cerca de una resistencia ({level})",
    r_near_support: "Precio cerca de un soporte ({level})", r_vol_spike: "Pico de volatilidad anormal", r_vol_flat: "Mercado demasiado plano",
    r_no_volume: "Volumen no disponible", r_no_calendar: "Calendario económico no conectado",
    r_horizon_short: "Vencimiento más corto que una vela", r_horizon_long: "Vencimiento muy largo respecto al timeframe",
    r_ai_agree: "La IA confirma el análisis", r_ai_disagree: "La IA rechaza la señal → NO TRADE",
  },
};

Object.assign(I18N.fr, {
  out_won: "gagné", out_lost: "perdu", out_draw: "égalité", out_unverifiable: "non vérifiable",
  tab_tests: "Tests", sim_banner: "🧪 SIMULATION sur vos données importées. Ce n'est PAS du trading sur Pocket Option et aucun ordre n'est envoyé. Les résultats dépendent entièrement des données fournies.",
  imp_title: "1. Importer des données historiques", imp_help: "Fichier CSV : « temps,open,high,low,close » (bougies de 5s, 10s, 15s ou 1m) ou « temps,prix » (ticks). Temps en secondes/millisecondes Unix ou date ISO. Séparateur , ou ; accepté. Aucune valeur n'est complétée ni inventée.",
  imp_name: "Nom du jeu de données", imp_label: "Origine (ex. : relevé manuel EUR/USD OTC sur Pocket Option)", imp_btn: "Importer",
  imp_ok: "Importé : {n} lignes ({kind}). Timeframes disponibles : {tfs}.", imp_need: "Choisissez un fichier.",
  kind_candles: "bougies", kind_ticks: "ticks", no_ds: "Aucune donnée importée.", del_confirm: "Supprimer ce jeu de données et ses simulations ?",
  test_params: "2. Paramètres du test", dataset: "Jeu de données", payout: "Gain si gagné (%)",
  threshold: "Seuil du score", threshold_help: "Plus le seuil est élevé, moins il y a de trades (seulement les signaux les plus nets).",
  backtest_run: "Lancer le backtest", tf_unavail: "Timeframe non disponible pour ces données.",
  bt_res: "Résultat du backtest", bt_trades: "Trades", bt_draws: "Égalités", bt_be: "Seuil de rentabilité", bt_pnl: "Gain/perte",
  bt_dd: "Baisse max", bt_streak: "Pertes d'affilée max", bt_split: "Stabilité : 70 % premiers / 30 % derniers trades",
  bt_dir: "Par direction", bt_note: "Résultat sur données importées uniquement. Un bon résultat passé ne garantit rien pour la suite.",
  replay_title: "3. Simulation pas à pas", replay_help: "Rejoue le marché bougie par bougie avec un solde virtuel, sans voir le futur : à chaque étape, le moteur décide UP, DOWN ou NO TRADE, puis le résultat est lu dans les bougies suivantes.",
  start_balance: "Solde virtuel de départ", replay_start: "Démarrer une simulation", step1: "▶ 1 étape", step10: "⏩ 10", step100: "⏭ 100",
  balance: "Solde virtuel", progress: "Avancement", finished: "Fin des données atteinte.",
  ev_time: "Heure", ev_dir: "Dir.", ev_res: "Résultat",
  sim_stats: "Statistiques de SIMULATION (données importées)", real_stats: "Signaux en direct Pocket Option",
  real_none: "Aucun : données Pocket Option non connectées.",
  err_halted: "Arrêt d'urgence actif : la simulation est bloquée.", err_dataset_not_found: "Jeu de données introuvable.",
  err_csv_too_large: "Fichier trop gros (3 Mo maximum).", err_bad_params: "Paramètres invalides.",
  tg_setup: "Configurer le bot Telegram", tg_help: "Enregistre le webhook, la commande /start et le bouton « Signal » qui ouvre l'appli dans Telegram.",
  tg_none: "TELEGRAM_BOT_TOKEN non configuré sur le serveur.", tg_bot: "Bot", tg_webhook: "Webhook", tg_ids: "ID autorisés",
  tg_ok: "Bot configuré. Ouvrez-le dans Telegram et tapez /start.", err_telegram_error: "Erreur Telegram",
});
Object.assign(I18N.en, {
  out_won: "won", out_lost: "lost", out_draw: "draw", out_unverifiable: "unverifiable",
  tab_tests: "Tests", sim_banner: "🧪 SIMULATION on your imported data. This is NOT trading on Pocket Option and no order is sent. Results depend entirely on the data provided.",
  imp_title: "1. Import historical data", imp_help: "CSV file: \"time,open,high,low,close\" (5s, 10s, 15s or 1m candles) or \"time,price\" (ticks). Time in Unix seconds/milliseconds or ISO date. , or ; separator accepted. No value is filled in or invented.",
  imp_name: "Dataset name", imp_label: "Origin (e.g. manual record EUR/USD OTC on Pocket Option)", imp_btn: "Import",
  imp_ok: "Imported: {n} rows ({kind}). Available timeframes: {tfs}.", imp_need: "Choose a file.",
  kind_candles: "candles", kind_ticks: "ticks", no_ds: "No imported data.", del_confirm: "Delete this dataset and its simulations?",
  test_params: "2. Test settings", dataset: "Dataset", payout: "Payout if won (%)",
  threshold: "Score threshold", threshold_help: "A higher threshold means fewer trades (only the clearest signals).",
  backtest_run: "Run backtest", tf_unavail: "Timeframe not available for this data.",
  bt_res: "Backtest result", bt_trades: "Trades", bt_draws: "Draws", bt_be: "Break-even", bt_pnl: "Profit/loss",
  bt_dd: "Max drawdown", bt_streak: "Max losing streak", bt_split: "Stability: first 70% / last 30% of trades",
  bt_dir: "By direction", bt_note: "Result on imported data only. Good past results guarantee nothing.",
  replay_title: "3. Step-by-step simulation", replay_help: "Replays the market candle by candle with a virtual balance, without seeing the future: at each step the engine decides UP, DOWN or NO TRADE, then the result is read from the following candles.",
  start_balance: "Starting virtual balance", replay_start: "Start a simulation", step1: "▶ 1 step", step10: "⏩ 10", step100: "⏭ 100",
  balance: "Virtual balance", progress: "Progress", finished: "End of data reached.",
  ev_time: "Time", ev_dir: "Dir.", ev_res: "Result",
  sim_stats: "SIMULATION statistics (imported data)", real_stats: "Live Pocket Option signals",
  real_none: "None: Pocket Option data not connected.",
  err_halted: "Emergency stop active: simulation is blocked.", err_dataset_not_found: "Dataset not found.",
  err_csv_too_large: "File too large (3 MB max).", err_bad_params: "Invalid settings.",
  tg_setup: "Set up Telegram bot", tg_help: "Registers the webhook, the /start command and the \"Signal\" button that opens the app in Telegram.",
  tg_none: "TELEGRAM_BOT_TOKEN not set on the server.", tg_bot: "Bot", tg_webhook: "Webhook", tg_ids: "Allowed IDs",
  tg_ok: "Bot configured. Open it in Telegram and type /start.", err_telegram_error: "Telegram error",
});
Object.assign(I18N.es, {
  out_won: "ganada", out_lost: "perdida", out_draw: "empate", out_unverifiable: "no verificable",
  tab_tests: "Pruebas", sim_banner: "🧪 SIMULACIÓN con tus datos importados. NO es trading en Pocket Option y no se envía ninguna orden. Los resultados dependen totalmente de los datos proporcionados.",
  imp_title: "1. Importar datos históricos", imp_help: "Archivo CSV: «tiempo,open,high,low,close» (velas de 5s, 10s, 15s o 1m) o «tiempo,precio» (ticks). Tiempo en segundos/milisegundos Unix o fecha ISO. Separador , o ; aceptado. No se completa ni inventa ningún valor.",
  imp_name: "Nombre del conjunto", imp_label: "Origen (ej.: registro manual EUR/USD OTC en Pocket Option)", imp_btn: "Importar",
  imp_ok: "Importado: {n} filas ({kind}). Timeframes disponibles: {tfs}.", imp_need: "Elige un archivo.",
  kind_candles: "velas", kind_ticks: "ticks", no_ds: "No hay datos importados.", del_confirm: "¿Eliminar este conjunto y sus simulaciones?",
  test_params: "2. Parámetros de la prueba", dataset: "Conjunto de datos", payout: "Pago si gana (%)",
  threshold: "Umbral de puntuación", threshold_help: "Cuanto más alto, menos operaciones (solo las señales más claras).",
  backtest_run: "Lanzar backtest", tf_unavail: "Timeframe no disponible para estos datos.",
  bt_res: "Resultado del backtest", bt_trades: "Operaciones", bt_draws: "Empates", bt_be: "Punto de equilibrio", bt_pnl: "Ganancia/pérdida",
  bt_dd: "Caída máx", bt_streak: "Pérdidas seguidas máx", bt_split: "Estabilidad: 70 % primeras / 30 % últimas operaciones",
  bt_dir: "Por dirección", bt_note: "Resultado solo con datos importados. Un buen resultado pasado no garantiza nada.",
  replay_title: "3. Simulación paso a paso", replay_help: "Reproduce el mercado vela a vela con saldo virtual, sin ver el futuro: en cada paso el motor decide UP, DOWN o NO TRADE y el resultado se lee en las velas siguientes.",
  start_balance: "Saldo virtual inicial", replay_start: "Iniciar simulación", step1: "▶ 1 paso", step10: "⏩ 10", step100: "⏭ 100",
  balance: "Saldo virtual", progress: "Avance", finished: "Fin de los datos.",
  ev_time: "Hora", ev_dir: "Dir.", ev_res: "Resultado",
  sim_stats: "Estadísticas de SIMULACIÓN (datos importados)", real_stats: "Señales en directo de Pocket Option",
  real_none: "Ninguna: datos de Pocket Option no conectados.",
  err_halted: "Parada de emergencia activa: simulación bloqueada.", err_dataset_not_found: "Conjunto no encontrado.",
  err_csv_too_large: "Archivo demasiado grande (3 MB máx).", err_bad_params: "Parámetros no válidos.",
  tg_setup: "Configurar el bot de Telegram", tg_help: "Registra el webhook, el comando /start y el botón «Signal» que abre la app en Telegram.",
  tg_none: "TELEGRAM_BOT_TOKEN no configurado en el servidor.", tg_bot: "Bot", tg_webhook: "Webhook", tg_ids: "IDs autorizados",
  tg_ok: "Bot configurado. Ábrelo en Telegram y escribe /start.", err_telegram_error: "Error de Telegram",
});

const LESSONS = {
  fr: [
    ["Pourquoi l'appli ne donne pas de signal aujourd'hui", "Un signal sérieux se calcule sur les vrais prix de la plateforme. Pocket Option ne fournit pas ces prix aux applications externes. Plutôt que d'inventer des chiffres, l'appli affiche « Non connecté »."],
    ["Timeframe ≠ durée du trade", "Le timeframe est la taille des bougies analysées (ex. 5 s). La durée est le temps avant l'expiration du trade (ex. 1 min). Ce sont deux réglages différents."],
    ["Les très courtes durées", "Sur 5 à 15 secondes, le mouvement des prix est très proche du hasard. Il faut des milliers d'essais pour savoir si une méthode fonctionne vraiment."],
    ["Le seuil de rentabilité", "Avec un gain de 85 %, il faut gagner plus de 54 % des trades pour ne pas perdre d'argent. 10 ou 20 trades ne prouvent rien."],
    ["Gestion du risque", "Petite mise, limite de perte par jour, jamais de martingale (doubler après une perte)."],
  ],
  en: [
    ["Why the app gives no signal today", "A serious signal is computed on the platform's real prices. Pocket Option doesn't provide these prices to external apps. Instead of inventing numbers, the app shows \"Not connected\"."],
    ["Timeframe ≠ trade duration", "The timeframe is the size of analysed candles (e.g. 5 s). The duration is the time until the trade expires (e.g. 1 min). They are two different settings."],
    ["Very short durations", "Over 5 to 15 seconds, price moves are very close to random. It takes thousands of trials to know whether a method really works."],
    ["Break-even", "With an 85% payout you must win more than 54% of trades to break even. 10 or 20 trades prove nothing."],
    ["Risk management", "Small stake, daily loss limit, never martingale (doubling after a loss)."],
  ],
  es: [
    ["Por qué la app no da señal hoy", "Una señal seria se calcula con los precios reales de la plataforma. Pocket Option no proporciona esos precios a apps externas. En lugar de inventar cifras, la app muestra «No conectado»."],
    ["Timeframe ≠ duración", "El timeframe es el tamaño de las velas analizadas (ej. 5 s). La duración es el tiempo hasta el vencimiento (ej. 1 min). Son dos ajustes distintos."],
    ["Duraciones muy cortas", "En 5 a 15 segundos, el movimiento del precio es casi aleatorio. Hacen falta miles de pruebas para saber si un método funciona."],
    ["Punto de equilibrio", "Con un pago del 85 % hay que ganar más del 54 % para no perder. 10 o 20 operaciones no prueban nada."],
    ["Gestión del riesgo", "Importe pequeño, límite de pérdida diaria, nunca martingala (doblar tras perder)."],
  ],
};

let lang = store.get("lang") || ((tg && tg.initDataUnsafe && tg.initDataUnsafe.user && tg.initDataUnsafe.user.language_code) || "fr").slice(0, 2);
if (!I18N[lang]) lang = "fr";
let CFG = null;
const state = { timeframe: "1m", duration: null };

const $ = (id) => document.getElementById(id);
const t = (k, v) => { let s = I18N[lang][k] ?? I18N.fr[k] ?? k; if (v) for (const x in v) s = s.replace(`{${x}}`, v[x]); return s; };
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmtTime = (ep) => new Date(ep * 1000).toLocaleString(lang, { hour: "2-digit", minute: "2-digit", second: "2-digit", day: "2-digit", month: "2-digit" });
const fmtSec = (s) => (s % 3600 === 0 ? s / 3600 + "h" : s % 60 === 0 ? s / 60 + "m" : s + "s");
const pct = (x) => (x == null ? "—" : (x * 100).toFixed(1) + " %");

function banner(msg, ok = false) {
  const b = $("banner");
  b.textContent = msg; b.className = "banner show" + (ok ? " ok" : "");
  clearTimeout(banner._t); banner._t = setTimeout(() => (b.className = "banner"), 6000);
}

async function api(path, body, method) {
  const headers = { "Content-Type": "application/json" };
  if (tg && tg.initData) headers["X-Telegram-Init-Data"] = tg.initData;
  const key = store.get("accessKey"); if (key) headers["X-Access-Key"] = key;
  const r = await fetch(path, { method: method || (body ? "POST" : "GET"), headers, body: body ? JSON.stringify(body) : undefined });
  let data = null; try { data = await r.json(); } catch (e) {}
  if (!r.ok) {
    const str = String((data && data.detail) || r.statusText), code = str.split(":")[0], rest = str.slice(code.length + 1).trim();
    const known = I18N[lang]["err_" + code];
    const err = new Error(known ? t("err_" + code) + (rest && code !== "po_not_connected" ? " — " + rest : "") : `${t("err_generic")} : ${str}`);
    err.status = r.status; err.code = code; throw err;
  }
  return data;
}

function applyI18n() {
  document.documentElement.lang = lang; $("lang").value = lang;
  document.querySelectorAll("[data-i18n]").forEach((el) => { el.textContent = t(el.dataset.i18n); });
  if (CFG) { renderStatus(); renderControls(); renderSettings(); renderLessons(); }
}

async function boot() {
  applyI18n();
  try { CFG = await api("/api/config"); }
  catch (e) { if (e.status === 401) { $("login").classList.remove("hidden"); return; } banner(e.message); return; }
  $("login").classList.add("hidden"); $("app").classList.remove("hidden"); $("nav").classList.remove("hidden");
  applyI18n();
}

$("loginBtn").onclick = () => { store.set("accessKey", $("accessKey").value.trim()); boot(); };
$("lang").onchange = (e) => { lang = e.target.value; store.set("lang", lang); applyI18n(); };
document.querySelectorAll("#nav button").forEach((b) => b.onclick = () => {
  document.querySelectorAll("#nav button").forEach((x) => x.classList.toggle("active", x === b));
  document.querySelectorAll("main .view").forEach((v) => v.classList.add("hidden"));
  $("v-" + b.dataset.v).classList.remove("hidden");
  ({ history: loadHistory, stats: loadStats, info: loadNews, settings: () => { renderSettings(); loadTelegram(); },
     tests: loadTests })[b.dataset.v]?.();
});

// ---------- État de la plateforme ----------
function renderStatus() {
  const p = CFG.platform;
  const tag = (ok) => `<span class="status ${ok ? "ok" : "ko"}">${ok ? t("st_on") : t("st_off")}</span>`;
  $("statusDot").classList.toggle("off", !p.data_connected);
  $("platformStatus").innerHTML = `<b>${t("st_title")}</b>
    <div class="line"><span>${t("st_data")}</span>${tag(p.data_connected)}</div>
    <div class="line"><span>${t("st_exec")}</span>${tag(p.execution_connected)}</div>
    ${p.data_connected ? "" : `<p class="muted small">${t("st_explain")}</p>`}`;
}

// ---------- Onglet Signal ----------
function renderControls() {
  const prev = $("asset").value;
  $("asset").innerHTML = CFG.settings.assets.map((a) => `<option value="${esc(a)}">${esc(a)}</option>`).join("");
  if (CFG.settings.assets.includes(prev)) $("asset").value = prev;
  const otc = /OTC$/i.test($("asset").value);
  $("assetNote").textContent = otc ? t("otc_note") : t("real_note");
  $("asset").onchange = renderControls;

  $("timeframes").innerHTML = CFG.timeframes.map((tf) =>
    `<button data-tf="${tf}" class="${state.timeframe === tf ? "on" : ""}">${tf}</button>`).join("");
  $("timeframes").querySelectorAll("button").forEach((b) => b.onclick = () => { state.timeframe = b.dataset.tf; renderControls(); });

  const ok = CFG.settings.po_expiries;
  if (!ok.includes(state.duration)) state.duration = ok.includes(60) ? 60 : (ok[0] ?? null);
  $("expiries").innerHTML = CFG.expiry_candidates.map((d) =>
    `<button data-s="${d}" ${ok.includes(d) ? "" : "disabled"} class="${state.duration === d ? "on" : ""}">${fmtSec(d)}</button>`).join("");
  $("expiries").querySelectorAll("button:not([disabled])").forEach((b) => b.onclick = () => { state.duration = +b.dataset.s; renderControls(); });
  $("expNote").textContent = ok.length ? (ok.length < CFG.expiry_candidates.length ? t("exp_note") : "") : t("exp_note_none");

  const prevM = $("model").value;
  $("model").innerHTML = CFG.providers.map((p) =>
    `<option value="${p.id}" ${p.connected ? "" : "disabled"}>${esc(p.name)}${p.connected ? "" : " — " + t("not_connected")}</option>`).join("");
  if (prevM && CFG.providers.find((p) => p.id === prevM && p.connected)) $("model").value = prevM;
}

$("signalBtn").onclick = async () => {
  if (!state.duration) { renderUnavailable(t("choose_expiry")); return; }
  const btn = $("signalBtn"); btn.disabled = true;
  $("result").classList.add("hidden"); $("progress").classList.remove("hidden");
  const steps = ["p1", "p2", "p3", $("model").value !== "technical" ? "p4" : null].filter(Boolean);
  let i = 0;
  const tick = () => { $("progressText").textContent = t(steps[Math.min(i, steps.length - 1)]);
    $("barFill").style.width = Math.min(90, ((i + 1) / (steps.length + 1)) * 100) + "%"; i++; };
  tick(); const timer = setInterval(tick, 700);
  try {
    const s = await api("/api/signal", { symbol: $("asset").value, timeframe: state.timeframe,
      duration_sec: state.duration, model: $("model").value, lang });
    $("barFill").style.width = "100%";
    renderResult(s);
  } catch (e) { renderUnavailable(e.message); }
  finally { clearInterval(timer); btn.disabled = false; setTimeout(() => $("progress").classList.add("hidden"), 300); }
};

function renderResult(s) {
  const label = s.direction === "NO_TRADE" ? t("no_trade") : s.direction;
  const conf = s.confidence != null ? `${pct(s.confidence)} <span class="muted small">(n=${s.confidence_n})</span>`
    : `<span class="small">${t("conf_none", { n: s.confidence_n })}</span>`;
  const mode = CFG.settings.mode;
  const canExec = s.direction !== "NO_TRADE" && mode !== "analysis" && !s.execution;
  $("result").innerHTML = `
    <div class="dir ${esc(s.direction)}">${s.direction === "UP" ? "▲ " : s.direction === "DOWN" ? "▼ " : ""}${esc(label)}</div>
    ${s.direction === "NO_TRADE" ? `<button class="notrade-btn" disabled>${t("no_trade_btn")}</button>` : ""}
    <div class="center"><b>${esc(s.symbol)}</b></div>
    <div class="kv">
      <div><b>${t("tf_used")}</b>${esc(s.timeframe)}</div>
      <div><b>${t("exp_used")}</b>${fmtSec(s.duration_sec)}</div>
      <div><b>${t("sig_time")}</b>${fmtTime(s.entry_epoch)}</div>
      <div><b>${t("expiry")}</b>${fmtTime(s.expiry_epoch)}</div>
      <div><b>${t("price")}</b>${s.price}</div>
      <div><b>${t("score")}</b>${s.score}/100</div>
      <div style="grid-column:1/-1"><b>${t("conf")}</b>${conf}</div>
      <div style="grid-column:1/-1"><b>${t("data_status")}</b><span class="status ok">${t("data_ok")}</span></div>
    </div>
    <b>${t("reasons")}</b>
    <ul class="reasons">${s.reasons.map((r) => `<li>${esc(t("r_" + r.key, r.v))}</li>`).join("")}</ul>
    ${s.ai_note ? `<p><b>${t("ai_note")} :</b> ${esc(s.ai_note)}</p>` : ""}
    ${s.execution ? `<p class="small"><b>${esc(s.execution.message)}</b></p>` : ""}
    ${canExec ? `<button id="execBtn" class="secondary">${t("exec_btn")} (${t("mode_" + mode)})</button>` : ""}
    <p class="muted small">${t("indicative")}</p>`;
  $("result").classList.remove("hidden");
  const eb = $("execBtn");
  if (eb) eb.onclick = async () => {
    eb.disabled = true;
    try { const r = await api("/api/execute", { signal_id: s.id }); banner(r.message, true); eb.remove(); }
    catch (e) { banner(e.message); eb.disabled = false; }
  };
}

function renderUnavailable(msg) {
  $("result").innerHTML = `
    <div class="dir NO_TRADE">${t("unavailable_title")}</div>
    <div class="kv">
      <div><b>${t("direction")}</b>—</div>
      <div><b>${t("sig_time")}</b>${fmtTime(Math.floor(Date.now() / 1000))}</div>
      <div><b>${t("tf_used")}</b>${esc(state.timeframe)}</div>
      <div><b>${t("exp_used")}</b>${state.duration ? fmtSec(state.duration) : "—"}</div>
      <div style="grid-column:1/-1"><b>${t("data_status")}</b><span class="status ko">${t("data_ko")}</span></div>
    </div>
    <p class="small">${esc(msg)}</p>`;
  $("result").classList.remove("hidden");
}

// ---------- Historique ----------
async function loadHistory() {
  try {
    const { signals, trades } = await api("/api/history");
    if (!signals.length) { $("historyList").innerHTML = `<div class="card muted">${t("no_history")}</div>`; return; }
    const bySig = {}; trades.forEach((tr) => { (bySig[tr.signal_id] ||= []).push(tr); });
    $("historyList").innerHTML = `<div class="card">` + signals.map((s) => {
      const status = s.status === "no_trade" ? t("no_trade") : s.status === "pending" ? t("pending") : t("out_" + s.status);
      const trs = (bySig[s.id] || []).map((tr) => `${t("mode_" + tr.mode)} · ${tr.status}${tr.profit != null ? " · " + tr.profit : ""}`).join("<br>");
      return `<div class="item"><div><b>${esc(s.symbol)}</b> · ${esc(s.action)} · ${esc(s.timeframe || "")} → ${s.duration_sec ? fmtSec(s.duration_sec) : ""}<br>
        <span class="muted small">${fmtTime(s.created_at)} · ${s.price}${s.exit_price != null ? " → " + s.exit_price : ""}</span>
        ${trs ? `<br><span class="small">${trs}</span>` : ""}</div><span class="tag ${esc(s.status)}">${esc(status)}</span></div>`;
    }).join("") + `</div>`;
  } catch (e) { banner(e.message); }
}

// ---------- Stats ----------
const rows = (list) => list.map((r) => `<div class="item"><span>${esc(r.k)}</span><span>${pct(r.win_rate)} <span class="muted small">(${r.won}/${r.n})</span></span></div>`).join("") || `<p class="muted small">—</p>`;
async function loadStats() {
  try {
    const s = await api("/api/stats");
    const ci = s.ci ? `${pct(s.ci[0])} – ${pct(s.ci[1])}` : "—";
    renderSimStats(s.simulation);
    $("statsBox").innerHTML = `
      <div class="card"><h3>${t("real_stats")}</h3>${s.total ? "" : `<p class="muted small">${t("real_none")}</p>`}<div class="grid3">
        <div><div class="big-num">${s.total}</div><span class="muted small">${t("total")}</span></div>
        <div><div class="big-num" style="color:var(--up)">${s.won}</div><span class="muted small">${t("won")}</span></div>
        <div><div class="big-num" style="color:var(--down)">${s.lost}</div><span class="muted small">${t("lost")}</span></div></div>
      <p><b>${t("winrate")} :</b> ${pct(s.win_rate)} · ${s.verified} ${t("samples")}</p>
      <p class="small muted">${t("ci")} : ${ci}${s.verified < 30 ? "<br>" + t("small_sample") : ""}</p>
      <p class="small muted">${t("pending")} : ${s.pending} · ${t("no_trade")} : ${s.no_trade}</p></div>
      <div class="card"><h3>${t("by_tf")}</h3>${rows(s.by_timeframe)}</div>
      <div class="card"><h3>${t("by_dur")}</h3>${rows(s.by_duration.map((r) => ({ ...r, k: fmtSec(r.k) })))}</div>
      <div class="card"><h3>${t("by_asset")}</h3>${rows(s.by_asset)}</div>
      <div class="card"><h3>${t("by_mode")}</h3>
        ${s.by_mode.map((m) => `<div class="item"><span>${t("mode_" + m.k)}</span><span>${m.won}/${m.n} · P&L ${m.pnl.toFixed(2)}</span></div>`).join("") || `<p class="muted small">—</p>`}
        <p class="small">${t("sim_balance")} : <b>${s.sim_balance.toFixed(2)}</b></p></div>`;
  } catch (e) { banner(e.message); }
}

function renderSimStats(m) {
  const ci = m.ci ? `${pct(m.ci[0])} – ${pct(m.ci[1])}` : "—";
  $("simStatsBox").innerHTML = `<div class="card sim-banner"><h3>${t("sim_stats")}</h3>
    <div class="grid3"><div><div class="big-num">${m.verified}</div><span class="muted small">${t("bt_trades")}</span></div>
    <div><div class="big-num" style="color:var(--up)">${m.wins}</div><span class="muted small">${t("won")}</span></div>
    <div><div class="big-num" style="color:var(--down)">${m.losses}</div><span class="muted small">${t("lost")}</span></div></div>
    <p><b>${t("winrate")} :</b> ${pct(m.win_rate)} · ${t("ci")} : ${ci}${m.verified < 30 ? "<br><span class='small muted'>" + t("small_sample") + "</span>" : ""}</p>
    <p class="small">${t("bt_pnl")} : ${m.pnl.toFixed(2)}</p>
    <h3>${t("by_tf")}</h3>${rows(m.by_timeframe)}
    <h3>${t("by_dur")}</h3>${rows(m.by_duration.map((r) => ({ ...r, k: fmtSec(r.k) })))}</div>`;
}

// ---------- Tests : import, backtest, simulation ----------
const T = { datasets: [], tf: "5s", dur: 15, replay: null };

async function loadTests() {
  try { T.datasets = await api("/api/datasets"); } catch (e) { banner(e.message); return; }
  renderDatasets(); renderTestControls();
}

function renderDatasets() {
  $("dsList").innerHTML = T.datasets.length ? T.datasets.map((d) => `<div class="ds"><div><b>${esc(d.name)}</b>
      <span class="muted small"> · ${d.count} ${t("kind_" + d.kind)}${d.base_tf ? " " + fmtSec(d.base_tf) : ""}</span><br>
      <span class="muted small">${esc(d.label || "")} ${fmtTime(d.start)} → ${fmtTime(d.end)} · ${d.timeframes.join(", ")}</span></div>
      <button data-del="${d.id}" aria-label="delete">✕</button></div>`).join("") : `<p class="muted small">${t("no_ds")}</p>`;
  $("dsList").querySelectorAll("[data-del]").forEach((b) => b.onclick = async () => {
    if (!confirm(t("del_confirm"))) return;
    try { await api("/api/datasets/" + b.dataset.del, undefined, "DELETE"); loadTests(); } catch (e) { banner(e.message); }
  });
  const prev = $("tDataset").value;
  $("tDataset").innerHTML = T.datasets.map((d) => `<option value="${d.id}">${esc(d.name)}</option>`).join("");
  if (T.datasets.some((d) => String(d.id) === prev)) $("tDataset").value = prev;
  $("tDataset").onchange = renderTestControls;
}

function currentDs() { return T.datasets.find((d) => String(d.id) === $("tDataset").value); }

function renderTestControls() {
  const ds = currentDs(), avail = ds ? ds.timeframes : [];
  if (avail.length && !avail.includes(T.tf)) T.tf = avail[0];
  $("tTf").innerHTML = CFG.timeframes.map((tf) => `<button data-tf="${tf}" ${avail.includes(tf) ? "" : "disabled"}
    class="${T.tf === tf ? "on" : ""}">${tf}</button>`).join("");
  $("tTf").querySelectorAll("button:not([disabled])").forEach((b) => b.onclick = () => { T.tf = b.dataset.tf; renderTestControls(); });
  const tfs = { "5s": 5, "10s": 10, "15s": 15, "1m": 60 }[T.tf];
  const okDur = CFG.expiry_candidates.filter((d) => d >= tfs && d % tfs === 0);
  if (!okDur.includes(T.dur)) T.dur = okDur[0];
  $("tDur").innerHTML = CFG.expiry_candidates.map((d) => `<button data-s="${d}" ${okDur.includes(d) ? "" : "disabled"}
    class="${T.dur === d ? "on" : ""}">${fmtSec(d)}</button>`).join("");
  $("tDur").querySelectorAll("button:not([disabled])").forEach((b) => b.onclick = () => { T.dur = +b.dataset.s; renderTestControls(); });
  $("btBtn").disabled = $("rStart").disabled = !ds;
}

$("tThr").oninput = () => { $("tThrVal").textContent = $("tThr").value; };

$("impBtn").onclick = async () => {
  const f = $("impFile").files[0];
  if (!f) { banner(t("imp_need")); return; }
  const b = $("impBtn"); b.disabled = true;
  try {
    const r = await api("/api/datasets", { name: $("impName").value || f.name, label: $("impLabel").value, csv: await f.text() });
    banner(t("imp_ok", { n: r.count, kind: t("kind_" + r.kind), tfs: r.timeframes.join(", ") }), true);
    $("impFile").value = ""; await loadTests(); $("tDataset").value = String(r.id); renderTestControls();
  } catch (e) { banner(e.message); }
  finally { b.disabled = false; }
};

function testParams() {
  return { dataset_id: +$("tDataset").value, timeframe: T.tf, duration_sec: T.dur, stake: parseFloat($("tStake").value) || 1,
           payout: (parseFloat($("tPayout").value) || 85) / 100, threshold: +$("tThr").value };
}

function spark(points) {
  if (!points || points.length < 2) return "";
  const w = 320, h = 90, lo = Math.min(...points), hi = Math.max(...points), span = hi - lo || 1;
  const xy = points.map((p, i) => `${(i / (points.length - 1)) * w},${h - 6 - ((p - lo) / span) * (h - 12)}`).join(" ");
  const up = points[points.length - 1] >= points[0];
  return `<svg class="spark" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none"><polyline fill="none" stroke-width="2"
    stroke="${up ? "var(--up)" : "var(--down)"}" points="${xy}"/></svg>`;
}

const rateTxt = (r) => r && r.n ? `${pct(r.win_rate)} (${r.wins}/${r.n})` : "—";

$("btBtn").onclick = async () => {
  const b = $("btBtn"); b.disabled = true; $("btResult").innerHTML = `<p class="muted small">…</p>`;
  try {
    const r = await api("/api/backtest", testParams());
    const ci = r.ci ? `${pct(r.ci[0])} – ${pct(r.ci[1])}` : "—";
    const good = r.win_rate != null && r.ci && r.ci[0] > r.breakeven;
    $("btResult").innerHTML = `<h3 style="margin-top:12px">${t("bt_res")}</h3>
      <p class="small muted">${esc(r.dataset.name)} · ${esc(r.timeframe)} → ${fmtSec(r.duration_sec)} · ${r.candles} · ${fmtTime(r.from)} → ${fmtTime(r.to)}</p>
      <div class="kv">
        <div><b>${t("bt_trades")}</b>${r.trades} <span class="muted small">(NO TRADE ${r.no_trade})</span></div>
        <div><b>${t("winrate")}</b>${pct(r.win_rate)}</div>
        <div><b>${t("won")} / ${t("lost")}</b>${r.wins} / ${r.losses}</div>
        <div><b>${t("bt_draws")}</b>${r.draws}</div>
        <div><b>${t("bt_be")}</b>${pct(r.breakeven)}</div>
        <div><b>${t("ci")}</b>${ci}</div>
        <div><b>${t("bt_pnl")}</b><span style="color:${r.pnl >= 0 ? "var(--up)" : "var(--down)"}">${r.pnl.toFixed(2)}</span></div>
        <div><b>${t("bt_dd")}</b>${r.max_drawdown.toFixed(2)}</div>
        <div><b>${t("bt_streak")}</b>${r.max_loss_streak}</div>
        <div><b>${t("bt_dir")}</b>▲ ${rateTxt(r.up)}<br>▼ ${rateTxt(r.down)}</div>
        <div style="grid-column:1/-1"><b>${t("bt_split")}</b>${rateTxt(r.first_70)} · ${rateTxt(r.last_30)}</div>
      </div>
      ${spark(r.equity)}
      <p class="small ${good ? "" : "muted"}">${r.trades < 30 ? t("small_sample") + " " : ""}${t("bt_note")}</p>`;
  } catch (e) { $("btResult").innerHTML = ""; banner(e.message); }
  finally { b.disabled = false; }
};

function renderReplay(rp) {
  T.replay = rp;
  const s = rp.summary, pctDone = Math.min(100, Math.round((rp.cursor / Math.max(1, rp.total_candles)) * 100));
  const ci = s.ci ? `${pct(s.ci[0])} – ${pct(s.ci[1])}` : "—";
  const evs = rp.trades.map((e) => `<tr><td>${fmtTime(e.epoch)}</td><td>${e.direction === "UP" ? "▲" : e.direction === "DOWN" ? "▼" : "—"}</td>
    <td><span class="tag ${e.outcome}">${e.outcome === "no_trade" ? "NO TRADE" : esc(t("out_" + e.outcome))}</span></td>
    <td style="text-align:right">${e.outcome === "no_trade" ? "" : (e.profit >= 0 ? "+" : "") + e.profit.toFixed(2)}</td></tr>`).join("");
  $("replayBox").innerHTML = `<div class="sim-banner card" style="margin-top:12px">${esc(rp.label)}</div>
    <p class="small muted">${esc(rp.dataset_name)} · ${esc(rp.timeframe)} → ${fmtSec(rp.duration_sec)}</p>
    <div class="kv">
      <div><b>${t("balance")}</b><span class="big-num" style="font-size:20px">${rp.balance.toFixed(2)}</span></div>
      <div><b>${t("progress")}</b>${pctDone} %</div>
      <div><b>${t("won")} / ${t("lost")}</b>${s.wins} / ${s.losses}</div>
      <div><b>${t("winrate")}</b>${pct(s.win_rate)}</div>
      <div style="grid-column:1/-1"><b>${t("ci")}</b>${ci} · NO TRADE ${s.no_trade}</div>
    </div>
    <div class="bar"><span style="width:${pctDone}%"></span></div>
    ${rp.finished ? `<p class="small"><b>${t("finished")}</b></p>` : `<div class="btn-row">
      <button data-n="1">${t("step1")}</button><button data-n="10">${t("step10")}</button><button data-n="100">${t("step100")}</button></div>`}
    <table class="mini"><tr class="muted"><td>${t("ev_time")}</td><td>${t("ev_dir")}</td><td>${t("ev_res")}</td><td></td></tr>${evs}</table>`;
  $("replayBox").querySelectorAll("[data-n]").forEach((b) => b.onclick = () => stepReplay(+b.dataset.n));
}

async function stepReplay(n) {
  $("replayBox").querySelectorAll("[data-n]").forEach((b) => (b.disabled = true));
  try { renderReplay(await api(`/api/replay/${T.replay.id}/step`, { n })); }
  catch (e) { banner(e.message); renderReplay(T.replay); }
}

$("rStart").onclick = async () => {
  try { renderReplay(await api("/api/replay/start", { ...testParams(), start_balance: parseFloat($("rBalance").value) || 1000 })); }
  catch (e) { banner(e.message); }
};

// ---------- Telegram ----------
async function loadTelegram() {
  try {
    const i = await api("/api/telegram");
    if (!i.configured) { $("tgBox").textContent = t("tg_none"); $("tgSetup").disabled = true; return; }
    $("tgSetup").disabled = false;
    $("tgBox").innerHTML = i.error ? esc(i.error) : `${t("tg_bot")} : <b>@${esc(i.bot)}</b><br>
      ${t("tg_webhook")} : ${i.webhook_url ? esc(i.webhook_url) : t("not_connected")}${i.last_error ? "<br>⚠️ " + esc(i.last_error) : ""}<br>
      ${t("tg_ids")} : ${i.allowed_ids}`;
  } catch (e) { $("tgBox").textContent = e.message; }
}
$("tgSetup").onclick = async () => {
  try { await api("/api/telegram/setup", {}); banner(t("tg_ok"), true); loadTelegram(); } catch (e) { banner(e.message); }
};

// ---------- Infos ----------
async function loadNews() {
  renderLessons();
  try {
    const n = await api("/api/news");
    if (!n.connected) { $("newsList").innerHTML = `<p class="muted small">${t("news_off")}</p>`; return; }
    $("newsList").innerHTML = n.items.map((it) => `<div class="item"><div>
      <a href="${esc(it.url)}" target="_blank" rel="noopener">${esc(it.headline)}</a><br>
      <span class="muted small">${esc(it.source)} · ${fmtTime(it.datetime)}</span></div></div>`).join("");
  } catch (e) { $("newsList").innerHTML = `<p class="muted small">${esc(e.message)}</p>`; }
}
function renderLessons() {
  $("lessons").innerHTML = LESSONS[lang].map(([h, p]) => `<p><b>${esc(h)}</b><br><span class="small">${esc(p)}</span></p>`).join("");
}

// ---------- Paramètres ----------
function renderSettings() {
  if (!CFG) return;
  const st = CFG.settings;
  $("haltBtn").textContent = st.halted === "1" ? t("halt_off") : t("halt_on");
  $("expChecks").innerHTML = CFG.expiry_candidates.map((d) =>
    `<label><input type="checkbox" value="${d}" ${st.po_expiries.includes(d) ? "checked" : ""}> ${fmtSec(d)}</label>`).join("");
  $("assetsBox").value = st.assets.join("\n");
  $("modeSel").innerHTML = Object.entries(CFG.modes).map(([m, ok]) =>
    `<option value="${m}" ${ok ? "" : "disabled"}>${t("mode_" + m)}${ok ? "" : " — " + t("unavailable")}</option>`).join("");
  $("modeSel").value = st.mode;
  $("modeNote").textContent = t("mode_note");
  $("stake").value = st.stake; $("stake").max = CFG.limits.max_stake;
  $("autoExec").checked = st.auto_execute === "1";
  $("limitsNote").textContent = t("limits", { s: CFG.limits.max_stake, l: CFG.limits.daily_loss, t: CFG.limits.max_trades });
  $("providerList").innerHTML = CFG.providers.map((p) => `<div class="item"><div><b>${esc(p.name)}</b><br>
    <span class="muted small">${esc(p.desc)}</span></div>
    <span class="tag ${p.connected ? "won" : ""}">${p.connected ? t("connected") : t("not_connected")}</span></div>`).join("");
}

$("savePo").onclick = async () => {
  const po_expiries = [...$("expChecks").querySelectorAll("input:checked")].map((x) => +x.value);
  const assets = $("assetsBox").value.split("\n").map((x) => x.trim()).filter(Boolean);
  try {
    CFG.settings = { ...CFG.settings, ...(await api("/api/settings", { po_expiries, assets })) };
    renderSettings(); renderControls(); banner(t("saved"), true);
  } catch (e) { banner(e.message); }
};

$("saveSettings").onclick = async () => {
  try {
    CFG.settings = { ...CFG.settings, ...(await api("/api/settings", {
      mode: $("modeSel").value, stake: parseFloat($("stake").value), auto_execute: $("autoExec").checked })) };
    renderSettings(); banner(t("saved"), true);
  } catch (e) { banner(e.message); }
};

$("haltBtn").onclick = async () => {
  try {
    const r = await api("/api/halt", { halted: CFG.settings.halted !== "1" });
    CFG.settings.halted = r.halted ? "1" : "0";
    if (r.halted) CFG.settings.auto_execute = "0";
    renderSettings(); banner(t("saved"), true);
  } catch (e) { banner(e.message); }
};

boot();
