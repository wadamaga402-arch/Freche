"""Stockage SQLite : signaux, trades, paramètres, journal d'erreurs."""
import json
import math
import sqlite3
import time
from typing import Dict, List, Optional

import market
from config import settings

SCHEMA = """
CREATE TABLE IF NOT EXISTS signals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at INTEGER, symbol TEXT, market TEXT, timeframe TEXT, duration_sec INTEGER, data_source TEXT,
  direction TEXT, action TEXT, score INTEGER, confidence REAL, confidence_n INTEGER,
  price REAL, entry_epoch INTEGER, expiry_epoch INTEGER, model TEXT, ai_note TEXT,
  reasons TEXT, status TEXT, exit_price REAL, exit_epoch INTEGER, mode TEXT
);
CREATE TABLE IF NOT EXISTS trades (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  signal_id INTEGER, created_at INTEGER, mode TEXT, symbol TEXT, direction TEXT,
  stake REAL, duration_sec INTEGER, contract_id TEXT, status TEXT, profit REAL, error TEXT
);
CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS datasets (
  id INTEGER PRIMARY KEY AUTOINCREMENT, created_at INTEGER, name TEXT, label TEXT, kind TEXT,
  base_tf INTEGER, count INTEGER, start INTEGER, end INTEGER, timeframes TEXT, data TEXT
);
CREATE TABLE IF NOT EXISTS replays (
  id INTEGER PRIMARY KEY AUTOINCREMENT, created_at INTEGER, dataset_id INTEGER, timeframe TEXT,
  duration_sec INTEGER, stake REAL, payout REAL, threshold INTEGER, cursor INTEGER,
  start_balance REAL, balance REAL, finished INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS replay_trades (
  id INTEGER PRIMARY KEY AUTOINCREMENT, replay_id INTEGER, epoch INTEGER, exit_epoch INTEGER,
  direction TEXT, score INTEGER, entry REAL, exit REAL, outcome TEXT, profit REAL, balance REAL
);
CREATE TABLE IF NOT EXISTS logs (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, level TEXT, msg TEXT);
"""

DEFAULTS = {"mode": "analysis", "halted": "0", "stake": "1", "auto_execute": "0",
            "sim_balance": str(settings.SIM_START_BALANCE),
            "assets": json.dumps(market.DEFAULT_ASSETS),      # liste indicative, modifiable
            "po_expiries": "[]"}                              # durées confirmées par l'utilisateur


def conn() -> sqlite3.Connection:
    c = sqlite3.connect(settings.DATABASE_PATH)
    c.row_factory = sqlite3.Row
    return c


MIGRATIONS = {"signals": {"timeframe": "TEXT", "duration_sec": "INTEGER", "data_source": "TEXT"},
              "trades": {"duration_sec": "INTEGER"}}


def init_db() -> None:
    with conn() as c:
        c.executescript(SCHEMA)
        for table, cols in MIGRATIONS.items():  # bases créées par la version précédente
            have = {r["name"] for r in c.execute(f"PRAGMA table_info({table})")}
            for col, typ in cols.items():
                if col not in have:
                    c.execute(f"ALTER TABLE {table} ADD COLUMN {col} {typ}")
        for k, v in DEFAULTS.items():
            c.execute("INSERT OR IGNORE INTO kv(k, v) VALUES(?, ?)", (k, v))


def get_setting(k: str) -> str:
    with conn() as c:
        row = c.execute("SELECT v FROM kv WHERE k=?", (k,)).fetchone()
    return row["v"] if row else DEFAULTS.get(k, "")


def set_setting(k: str, v) -> None:
    with conn() as c:
        c.execute("INSERT INTO kv(k, v) VALUES(?, ?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", (k, str(v)))


def log(level: str, msg: str) -> None:
    with conn() as c:
        c.execute("INSERT INTO logs(ts, level, msg) VALUES(?,?,?)", (int(time.time()), level, msg[:1000]))


def recent_logs(limit: int = 50) -> List[Dict]:
    with conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM logs ORDER BY id DESC LIMIT ?", (limit,))]


def insert_signal(d: Dict) -> int:
    with conn() as c:
        cur = c.execute(
            """INSERT INTO signals(created_at, symbol, market, timeframe, duration_sec, data_source, direction,
               action, score, confidence, confidence_n, price, entry_epoch, expiry_epoch, model, ai_note, reasons,
               status, mode) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (int(time.time()), d["symbol"], d["market"], d["timeframe"], d["duration_sec"], d.get("data_source"),
             d["direction"], d["action"],
             d["score"], d.get("confidence"), d.get("confidence_n"), d["price"], d["entry_epoch"],
             d["expiry_epoch"], d["model"], d.get("ai_note"), json.dumps(d["reasons"]),
             "no_trade" if d["direction"] == "NO_TRADE" else "pending", d["mode"]))
        return cur.lastrowid


def pending_signals(now: int) -> List[Dict]:
    with conn() as c:
        return [dict(r) for r in c.execute(
            "SELECT * FROM signals WHERE status='pending' AND expiry_epoch<=?", (now,))]


def resolve_outcome(direction: str, entry: float, exit_: float) -> str:
    """Règle de résultat (Rise/Fall) : UP gagne si sortie > entrée ; égalité = draw."""
    if exit_ == entry:
        return "draw"
    return "won" if (exit_ > entry) == (direction == "UP") else "lost"


def set_signal_result(sid: int, status: str, exit_price: Optional[float], exit_epoch: Optional[int]) -> None:
    with conn() as c:
        c.execute("UPDATE signals SET status=?, exit_price=?, exit_epoch=? WHERE id=?",
                  (status, exit_price, exit_epoch, sid))


def list_signals(limit: int = 100) -> List[Dict]:
    with conn() as c:
        rows = [dict(r) for r in c.execute("SELECT * FROM signals ORDER BY id DESC LIMIT ?", (limit,))]
    for r in rows:
        r["reasons"] = json.loads(r["reasons"] or "[]")
    return rows


# ---- Trades ----
def insert_trade(d: Dict) -> int:
    with conn() as c:
        cur = c.execute(
            """INSERT INTO trades(signal_id, created_at, mode, symbol, direction, stake, duration_sec,
               contract_id, status, profit, error) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
            (d.get("signal_id"), int(time.time()), d["mode"], d["symbol"], d["direction"], d["stake"],
             d["duration_sec"], d.get("contract_id"), d["status"], d.get("profit"), d.get("error")))
        return cur.lastrowid


def update_trade(tid: int, status: str, profit: Optional[float] = None, error: Optional[str] = None) -> None:
    with conn() as c:
        c.execute("UPDATE trades SET status=?, profit=?, error=COALESCE(?, error) WHERE id=?",
                  (status, profit, error, tid))


def open_trades() -> List[Dict]:
    with conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM trades WHERE status='open'")]


def trades_for_signal(sid: int) -> List[Dict]:
    with conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM trades WHERE signal_id=?", (sid,))]


def list_trades(limit: int = 100) -> List[Dict]:
    with conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM trades ORDER BY id DESC LIMIT ?", (limit,))]


def today_stats(mode: str) -> Dict:
    start = int(time.time()) - int(time.time()) % 86400  # minuit UTC
    with conn() as c:
        row = c.execute(
            """SELECT COUNT(*) n, COALESCE(SUM(CASE WHEN profit<0 THEN -profit ELSE 0 END),0) loss,
               COALESCE(SUM(profit),0) pnl FROM trades WHERE mode=? AND created_at>=? AND status!='error'""",
            (mode, start)).fetchone()
    return {"count": row["n"], "loss": row["loss"], "pnl": row["pnl"]}


# ---- Statistiques ----
def wilson(wins: int, n: int, z: float = 1.96):
    if n == 0:
        return None
    p = wins / n
    den = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / den
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return [max(0.0, centre - half), min(1.0, centre + half)]


BUCKETS = [(40, 59), (60, 79), (80, 100)]


def calibrated_confidence(score: int) -> Dict:
    """Confiance = taux de réussite historique VÉRIFIÉ des signaux de même force.
    Si l'échantillon est trop petit, on le dit au lieu d'inventer un pourcentage."""
    s = abs(score)
    bucket = next(((lo, hi) for lo, hi in BUCKETS if lo <= s <= hi), None)
    if not bucket:
        return {"value": None, "n": 0}
    with conn() as c:
        row = c.execute(
            """SELECT SUM(status='won') w, SUM(status IN ('won','lost')) n FROM signals
               WHERE ABS(score) BETWEEN ? AND ?""", bucket).fetchone()
    n, w = row["n"] or 0, row["w"] or 0
    if n < settings.MIN_CALIBRATION_SAMPLES:
        return {"value": None, "n": n}
    return {"value": w / n, "n": n, "ci": wilson(w, n)}


def stats() -> Dict:
    with conn() as c:
        tot = c.execute("""SELECT COUNT(*) total, SUM(status='won') won, SUM(status='lost') lost,
                           SUM(status='draw') draw, SUM(status='pending') pending,
                           SUM(status='no_trade') no_trade FROM signals""").fetchone()
        by_asset = [dict(r) for r in c.execute(
            """SELECT symbol k, SUM(status='won') won, SUM(status='lost') lost FROM signals
               GROUP BY symbol HAVING won+lost>0 ORDER BY won+lost DESC""")]
        by_dur = [dict(r) for r in c.execute(
            """SELECT duration_sec k, SUM(status='won') won, SUM(status='lost') lost FROM signals
               WHERE duration_sec IS NOT NULL GROUP BY duration_sec HAVING won+lost>0 ORDER BY duration_sec""")]
        by_tf = [dict(r) for r in c.execute(
            """SELECT timeframe k, SUM(status='won') won, SUM(status='lost') lost FROM signals
               WHERE timeframe IS NOT NULL GROUP BY timeframe HAVING won+lost>0""")]
        by_mode = [dict(r) for r in c.execute(
            """SELECT mode k, COUNT(*) n, SUM(status='won') won, SUM(status='lost') lost,
               COALESCE(SUM(profit),0) pnl FROM trades GROUP BY mode""")]
    won, lost = tot["won"] or 0, tot["lost"] or 0
    n = won + lost
    for row in by_asset + by_dur + by_tf:
        m = row["won"] + row["lost"]
        row["n"], row["win_rate"], row["ci"] = m, row["won"] / m, wilson(row["won"], m)
    return {
        "total": tot["total"] or 0, "won": won, "lost": lost, "draw": tot["draw"] or 0,
        "pending": tot["pending"] or 0, "no_trade": tot["no_trade"] or 0,
        "verified": n, "win_rate": (won / n) if n else None, "ci": wilson(won, n),
        "by_asset": by_asset, "by_duration": by_dur, "by_timeframe": by_tf, "by_mode": by_mode,
        "sim_balance": float(get_setting("sim_balance")),
    }


def get_json(k: str):
    try:
        return json.loads(get_setting(k))
    except (ValueError, TypeError):
        return json.loads(DEFAULTS[k])


# ---- Jeux de données importés ----
def insert_dataset(name: str, label: str, parsed: Dict) -> int:
    with conn() as c:
        cur = c.execute(
            """INSERT INTO datasets(created_at, name, label, kind, base_tf, count, start, end, timeframes, data)
               VALUES(?,?,?,?,?,?,?,?,?,?)""",
            (int(time.time()), name, label, parsed["kind"], parsed["base_tf"], parsed["count"], parsed["start"],
             parsed["end"], json.dumps(parsed["timeframes"]), json.dumps(parsed["rows"], separators=(",", ":"))))
        return cur.lastrowid


def list_datasets() -> List[Dict]:
    with conn() as c:
        rows = [dict(r) for r in c.execute(
            "SELECT id, created_at, name, label, kind, base_tf, count, start, end, timeframes FROM datasets ORDER BY id DESC")]
    for r in rows:
        r["timeframes"] = json.loads(r["timeframes"])
    return rows


def get_dataset(did: int) -> Optional[Dict]:
    with conn() as c:
        r = c.execute("SELECT * FROM datasets WHERE id=?", (did,)).fetchone()
    if not r:
        return None
    d = dict(r)
    d["rows"] = json.loads(d.pop("data"))
    d["timeframes"] = json.loads(d["timeframes"])
    return d


def delete_dataset(did: int) -> None:
    with conn() as c:
        ids = [r["id"] for r in c.execute("SELECT id FROM replays WHERE dataset_id=?", (did,))]
        for rid in ids:
            c.execute("DELETE FROM replay_trades WHERE replay_id=?", (rid,))
        c.execute("DELETE FROM replays WHERE dataset_id=?", (did,))
        c.execute("DELETE FROM datasets WHERE id=?", (did,))


# ---- Simulation (rejeu sur données importées) ----
def create_replay(d: Dict) -> int:
    with conn() as c:
        cur = c.execute(
            """INSERT INTO replays(created_at, dataset_id, timeframe, duration_sec, stake, payout, threshold, cursor,
               start_balance, balance) VALUES(?,?,?,?,?,?,?,?,?,?)""",
            (int(time.time()), d["dataset_id"], d["timeframe"], d["duration_sec"], d["stake"], d["payout"],
             d["threshold"], d["cursor"], d["start_balance"], d["start_balance"]))
        return cur.lastrowid


def get_replay(rid: int) -> Optional[Dict]:
    with conn() as c:
        r = c.execute("SELECT * FROM replays WHERE id=?", (rid,)).fetchone()
    return dict(r) if r else None


def list_replays(limit: int = 20) -> List[Dict]:
    with conn() as c:
        return [dict(r) for r in c.execute(
            """SELECT r.*, d.name dataset_name,
                      (SELECT COUNT(*) FROM replay_trades t WHERE t.replay_id=r.id AND t.outcome!='no_trade') n
               FROM replays r LEFT JOIN datasets d ON d.id=r.dataset_id ORDER BY r.id DESC LIMIT ?""", (limit,))]


def save_replay_events(rid: int, events: List[Dict], cursor: int, finished: bool) -> Dict:
    with conn() as c:
        bal = c.execute("SELECT balance FROM replays WHERE id=?", (rid,)).fetchone()["balance"]
        for e in events:
            bal += e["profit"]
            c.execute(
                """INSERT INTO replay_trades(replay_id, epoch, exit_epoch, direction, score, entry, exit, outcome,
                   profit, balance) VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (rid, e["epoch"], e.get("exit_epoch"), e["direction"], e["score"], e.get("entry"), e.get("exit"),
                 e["outcome"], e["profit"], round(bal, 4)))
        c.execute("UPDATE replays SET cursor=?, balance=?, finished=? WHERE id=?",
                  (cursor, round(bal, 4), 1 if finished else 0, rid))
    return get_replay(rid)


def replay_trades(rid: int, limit: int = 30) -> List[Dict]:
    with conn() as c:
        return [dict(r) for r in c.execute(
            """SELECT * FROM replay_trades WHERE replay_id=? AND outcome IN ('won','lost','draw')
               ORDER BY id DESC LIMIT ?""", (rid, limit))]


def replay_summary(rid: int) -> Dict:
    with conn() as c:
        r = c.execute("""SELECT SUM(outcome='won') w, SUM(outcome='lost') l, SUM(outcome='draw') d,
                         SUM(outcome='no_trade') nt FROM replay_trades WHERE replay_id=?""", (rid,)).fetchone()
    w, l = r["w"] or 0, r["l"] or 0
    return {"wins": w, "losses": l, "draws": r["d"] or 0, "no_trade": r["nt"] or 0,
            "win_rate": (w / (w + l)) if w + l else None, "ci": wilson(w, w + l)}


def sim_stats() -> Dict:
    """Statistiques de SIMULATION (rejeu sur données importées), séparées des signaux réels."""
    with conn() as c:
        tot = c.execute("""SELECT SUM(outcome='won') w, SUM(outcome='lost') l, COALESCE(SUM(profit),0) pnl
                           FROM replay_trades""").fetchone()
        def grouped(col):
            out = []
            for r in c.execute(f"""SELECT r.{col} k, SUM(t.outcome='won') won, SUM(t.outcome='lost') lost
                                   FROM replay_trades t JOIN replays r ON r.id=t.replay_id
                                   GROUP BY r.{col} HAVING won+lost>0 ORDER BY r.{col}"""):
                d = dict(r); m = d["won"] + d["lost"]
                d.update(n=m, win_rate=d["won"] / m, ci=wilson(d["won"], m)); out.append(d)
            return out
        by_tf, by_dur = grouped("timeframe"), grouped("duration_sec")
    w, l = tot["w"] or 0, tot["l"] or 0
    return {"wins": w, "losses": l, "verified": w + l, "win_rate": (w / (w + l)) if w + l else None,
            "ci": wilson(w, w + l), "pnl": round(tot["pnl"], 2), "by_timeframe": by_tf, "by_duration": by_dur}
