"""Intégration Telegram (API officielle Bot API).

- /start : envoie un bouton qui ouvre la Mini App (seulement pour les ID autorisés).
- /status : rappelle l'état de la connexion Pocket Option.
- setup() : enregistre le webhook, le bouton de menu et les commandes du bot.
Le token du bot reste côté serveur (variable TELEGRAM_BOT_TOKEN)."""
import hashlib
import hmac
from typing import Dict, Optional

import httpx

import market
from config import settings

_transport: Optional[httpx.AsyncBaseTransport] = None  # remplacé dans les tests


def webhook_secret() -> str:
    """Secret dérivé du token : Telegram le renvoie dans l'en-tête X-Telegram-Bot-Api-Secret-Token."""
    return hashlib.sha256(("webhook:" + settings.TELEGRAM_BOT_TOKEN).encode()).hexdigest()[:48]


def check_secret(header_value: str) -> bool:
    return bool(settings.TELEGRAM_BOT_TOKEN) and hmac.compare_digest(header_value or "", webhook_secret())


def public_url() -> str:
    return (settings.PUBLIC_URL or "").rstrip("/")


async def call(method: str, payload: Dict) -> Dict:
    if not settings.TELEGRAM_BOT_TOKEN:
        raise RuntimeError("TELEGRAM_BOT_TOKEN non configuré.")
    async with httpx.AsyncClient(timeout=15, transport=_transport) as c:
        r = await c.post(f"https://api.telegram.org/bot{settings.TELEGRAM_BOT_TOKEN}/{method}", json=payload)
    data = r.json()
    if not data.get("ok"):
        raise RuntimeError(f"Telegram {method} : {data.get('description', 'erreur')}")
    return data.get("result")


def is_allowed(user_id) -> bool:
    return str(user_id) in settings.ALLOWED_TELEGRAM_IDS


def status_text() -> str:
    st = market.status()
    return ("📊 AI Signal Bot — Pocket Option\n"
            f"Données : {'connecté' if st['data_connected'] else 'non connecté'}\n"
            f"Exécution : {'connecté' if st['execution_connected'] else 'non connecté'}\n\n"
            "Pocket Option ne propose pas d'API officielle : aucun signal en direct ni ordre automatique. "
            "Les tests et la simulation fonctionnent sur vos données importées.")


async def handle_update(update: Dict) -> Optional[Dict]:
    msg = update.get("message") or {}
    text = (msg.get("text") or "").strip()
    chat_id = (msg.get("chat") or {}).get("id")
    user_id = (msg.get("from") or {}).get("id")
    if not chat_id or not text.startswith("/"):
        return None
    cmd = text.split()[0].split("@")[0].lower()
    if not is_allowed(user_id):
        return await call("sendMessage", {"chat_id": chat_id, "text":
            f"⛔ Accès non autorisé.\nVotre ID Telegram : {user_id}\n"
            "Le propriétaire doit l'ajouter dans ALLOWED_TELEGRAM_IDS sur le serveur."})
    if cmd in ("/start", "/app"):
        url = public_url()
        if not url:
            return await call("sendMessage", {"chat_id": chat_id, "text": "PUBLIC_URL non configurée sur le serveur."})
        return await call("sendMessage", {
            "chat_id": chat_id,
            "text": status_text() + "\n\nTouchez le bouton pour ouvrir l'application.",
            "reply_markup": {"inline_keyboard": [[{"text": "📈 Ouvrir AI Signal Bot", "web_app": {"url": url}}]]},
        })
    if cmd == "/status":
        return await call("sendMessage", {"chat_id": chat_id, "text": status_text()})
    return await call("sendMessage", {"chat_id": chat_id, "text": "Commandes : /start, /status"})


async def setup() -> Dict:
    url = public_url()
    if not url:
        raise RuntimeError("PUBLIC_URL inconnue (sur Render elle est détectée automatiquement).")
    await call("setWebhook", {"url": f"{url}/telegram/webhook", "secret_token": webhook_secret(),
                              "allowed_updates": ["message"], "drop_pending_updates": True})
    await call("setChatMenuButton", {"menu_button": {"type": "web_app", "text": "Signal", "web_app": {"url": url}}})
    await call("setMyCommands", {"commands": [{"command": "start", "description": "Ouvrir l'application"},
                                              {"command": "status", "description": "État Pocket Option"}]})
    me = await call("getMe", {})
    return {"ok": True, "bot": me.get("username"), "webhook": f"{url}/telegram/webhook", "menu_url": url}


async def info() -> Dict:
    if not settings.TELEGRAM_BOT_TOKEN:
        return {"configured": False}
    try:
        me = await call("getMe", {})
        wh = await call("getWebhookInfo", {})
    except Exception as e:
        return {"configured": True, "error": str(e)}
    return {"configured": True, "bot": me.get("username"), "webhook_url": wh.get("url", ""),
            "pending": wh.get("pending_update_count", 0), "last_error": wh.get("last_error_message"),
            "public_url": public_url(), "allowed_ids": len(settings.ALLOWED_TELEGRAM_IDS)}
