"""Configuration des tests. Les bougies générées ici sont des DONNÉES DE TEST
synthétiques, uniquement pour vérifier la logique — jamais affichées comme réelles."""
import math
import os
import sys
import tempfile
import time

os.environ["DATABASE_PATH"] = os.path.join(tempfile.mkdtemp(), "test.db")
os.environ["ACCESS_KEY"] = "test-key"
os.environ["TELEGRAM_BOT_TOKEN"] = "123456:TEST"


os.environ["ANTHROPIC_API_KEY"] = ""
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def make_candles(n=200, start=100.0, drift=0.05, gran=60, end=None, wiggle=0.3):
    end = end or int(time.time())
    out, price = [], start
    for i in range(n):
        o = price
        c = o + drift + wiggle * math.sin(i / 3)
        out.append({"epoch": end - (n - 1 - i) * gran, "open": o, "close": c,
                    "high": max(o, c) + 0.1, "low": min(o, c) - 0.1})
        price = c
    return out
