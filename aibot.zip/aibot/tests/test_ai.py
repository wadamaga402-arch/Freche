import asyncio
import json
import httpx
import pytest

import ai_providers
from config import settings

RESULT = {"direction": "UP", "score": 55, "indicators": {"rsi": 60}, "reasons": [{"key": "trend_up"}]}


def run(pid, reply, monkeypatch, status=200):
    seen = {}

    def handler(req):
        seen["url"] = str(req.url); seen["headers"] = dict(req.headers); seen["body"] = json.loads(req.content)
        return httpx.Response(status, json=reply)
    monkeypatch.setattr(ai_providers, "_transport", httpx.MockTransport(handler))
    return asyncio.run(ai_providers.review(pid, "EUR/USD OTC", "5s", "15s", RESULT, "fr")), seen


def test_not_connected_by_default():
    assert ai_providers.is_connected("technical")
    assert not ai_providers.is_connected("claude") and not ai_providers.is_connected("openai")


def test_claude_review(monkeypatch):
    monkeypatch.setattr(settings, "ANTHROPIC_API_KEY", "sk-test")
    out, seen = run("claude", {"content": [{"type": "text", "text": '{"verdict":"DISAGREE","note":"faible"}'}]}, monkeypatch)
    assert out == {"verdict": "DISAGREE", "note": "faible"}
    assert seen["url"] == "https://api.anthropic.com/v1/messages"
    assert seen["headers"]["x-api-key"] == "sk-test"
    assert "5s" in seen["body"]["messages"][0]["content"]


def test_openai_review(monkeypatch):
    monkeypatch.setattr(settings, "OPENAI_API_KEY", "sk-o")
    monkeypatch.setattr(settings, "OPENAI_MODEL", "model-x")
    out, seen = run("openai", {"choices": [{"message": {"content": '{"verdict":"AGREE","note":"ok"}'}}]}, monkeypatch)
    assert out["verdict"] == "AGREE" and seen["body"]["model"] == "model-x"


def test_invalid_ai_answer_raises(monkeypatch):
    monkeypatch.setattr(settings, "ANTHROPIC_API_KEY", "sk-test")
    with pytest.raises(Exception):
        run("claude", {"content": [{"type": "text", "text": "UP sûr à 100 %"}]}, monkeypatch)
    with pytest.raises(httpx.HTTPStatusError):
        run("claude", {"error": "x"}, monkeypatch, status=500)
