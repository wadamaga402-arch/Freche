import time
import pytest
from fastapi.testclient import TestClient

import main, market, storage
from conftest import make_candles

H = {"X-Access-Key": "test-key"}
SIG = {"symbol": "EUR/USD OTC", "timeframe": "5s", "duration_sec": 15}


class FakeOfficialFeed:
    """Flux de TEST uniquement : simule un futur accès officiel pour vérifier que le moteur
    est prêt. Jamais utilisé par l'application réelle."""
    connected = True
    data_reason = ""
    execution_reason = "test"

    async def get_candles_tf(self, asset, tf, count=200):
        return {"candles": make_candles(200, drift=0.2, wiggle=0.05, gran=tf), "data": {"source": "test"}}

    async def get_price_at(self, asset, epoch):
        return {"price": 101.0, "epoch": epoch}


@pytest.fixture()
def client():
    with TestClient(main.app) as c:
        for k, v in (("halted", "0"), ("mode", "analysis"), ("auto_execute", "0"), ("po_expiries", "[5, 15, 60]")):
            storage.set_setting(k, v)
        yield c


@pytest.fixture()
def connected(monkeypatch):
    monkeypatch.setattr(market, "feed", FakeOfficialFeed())


def test_auth_required(client):
    assert client.get("/api/config").status_code == 401
    assert client.get("/api/config", headers={"X-Access-Key": "bad"}).status_code == 401


def test_config_reports_pocket_option_not_connected(client):
    cfg = client.get("/api/config", headers=H).json()
    assert cfg["platform"]["platform"] == "Pocket Option"
    assert cfg["platform"]["data_connected"] is False
    assert cfg["modes"] == {"analysis": True, "simulation": False, "demo": False, "real": False}
    assert cfg["timeframes"] == ["5s", "10s", "15s", "1m"]
    assert next(p for p in cfg["providers"] if p["id"] == "claude")["connected"] is False


def test_signal_refused_without_connection(client):
    before = len(storage.list_signals(1000))
    r = client.post("/api/signal", headers=H, json=SIG)
    assert r.status_code == 503 and "po_not_connected" in r.text
    assert len(storage.list_signals(1000)) == before   # aucun faux signal enregistré


def test_expiry_must_be_confirmed(client):
    r = client.post("/api/signal", headers=H, json={**SIG, "duration_sec": 10})
    assert r.status_code == 400 and "expiry_not_confirmed" in r.text


def test_bad_inputs(client):
    assert client.post("/api/signal", headers=H, json={**SIG, "timeframe": "5m"}).status_code == 400
    assert client.post("/api/signal", headers=H, json={**SIG, "symbol": "XYZ"}).status_code == 400
    assert client.post("/api/signal", headers=H, json={**SIG, "duration_sec": 30}).status_code == 400
    assert client.post("/api/signal", headers=H, json={**SIG, "model": "claude"}).status_code == 400


def test_demo_real_simulation_unavailable(client):
    for m in ("demo", "real", "simulation"):
        r = client.post("/api/settings", headers=H, json={"mode": m})
        assert r.status_code == 400 and "mode_unavailable" in r.text


def test_settings_assets_and_expiries(client):
    r = client.post("/api/settings", headers=H, json={"assets": ["EUR/USD OTC", " ", "AUD/CAD OTC"],
                                                       "po_expiries": [5, 10, 999]}).json()
    assert r["assets"] == ["EUR/USD OTC", "AUD/CAD OTC"] and r["po_expiries"] == [5, 10]
    client.post("/api/settings", headers=H, json={"assets": market.DEFAULT_ASSETS})


def test_engine_ready_for_future_official_feed(client, connected):
    s = client.post("/api/signal", headers=H, json=SIG).json()
    assert s["timeframe"] == "5s" and s["duration_sec"] == 15
    assert s["direction"] in ("UP", "DOWN", "NO_TRADE")
    assert s["expiry_epoch"] - s["entry_epoch"] == 15
    assert s["confidence"] is None


def test_simulation_and_halt_with_future_feed(client, connected, monkeypatch):
    import engine
    real = engine.analyze
    def forced_up(*a, **k):
        r = real(*a, **k); r["direction"] = r["action"] = "UP"; return r
    monkeypatch.setattr(engine, "analyze", forced_up)
    assert client.post("/api/settings", headers=H, json={"mode": "simulation", "stake": 1, "auto_execute": True}).status_code == 200
    s = client.post("/api/signal", headers=H, json=SIG).json()
    assert s["execution"]["status"] == "open" and "SIMUL" in s["execution"]["message"]
    client.post("/api/halt", headers=H, json={"halted": True})
    s2 = client.post("/api/signal", headers=H, json=SIG).json()
    assert s2["execution"] is None


def test_resolution_waits_without_connection(client):
    sid = storage.insert_signal({"symbol": "EUR/USD OTC", "market": "otc", "timeframe": "5s", "duration_sec": 15,
        "direction": "UP", "action": "UP", "score": 50, "price": 100.0, "entry_epoch": 1,
        "expiry_epoch": int(time.time()) - 10, "model": "technical", "reasons": [], "mode": "analysis"})
    import asyncio
    asyncio.run(main.resolve_pending_once())
    assert next(x for x in storage.list_signals() if x["id"] == sid)["status"] == "pending"  # rien n'est supposé


def test_resolution_with_future_feed(client, connected):
    sid = storage.insert_signal({"symbol": "EUR/USD OTC", "market": "otc", "timeframe": "1m", "duration_sec": 60,
        "direction": "UP", "action": "UP", "score": 50, "price": 100.0, "entry_epoch": 1,
        "expiry_epoch": int(time.time()) - 10, "model": "technical", "reasons": [], "mode": "simulation"})
    storage.insert_trade({"signal_id": sid, "mode": "simulation", "symbol": "EUR/USD OTC", "direction": "UP",
                          "stake": 2.0, "duration_sec": 60, "status": "open"})
    before = float(storage.get_setting("sim_balance"))
    import asyncio
    asyncio.run(main.resolve_pending_once())
    sig = next(x for x in storage.list_signals() if x["id"] == sid)
    assert sig["status"] == "won"
    assert float(storage.get_setting("sim_balance")) == pytest.approx(before + 1.7)
    s = client.get("/api/stats", headers=H).json()
    assert any(r["k"] == "1m" for r in s["by_timeframe"])


def _import(client, tf=5, n=1500):
    from test_market import csv_text
    r = client.post("/api/datasets", headers=H, json={"name": "test", "label": "données de test", "csv": csv_text(n, tf)})
    assert r.status_code == 200, r.text
    return r.json()


def test_dataset_import_list_delete(client):
    d = _import(client)
    assert d["kind"] == "candles" and d["timeframes"] == ["5s", "10s", "15s", "1m"]
    assert any(x["id"] == d["id"] for x in client.get("/api/datasets", headers=H).json())
    assert client.delete(f"/api/datasets/{d['id']}", headers=H).status_code == 200
    assert not any(x["id"] == d["id"] for x in client.get("/api/datasets", headers=H).json())


def test_dataset_invalid(client):
    r = client.post("/api/datasets", headers=H, json={"name": "x", "csv": "n'importe quoi"})
    assert r.status_code == 422 and "csv_invalid" in r.text


def test_backtest_on_dataset(client):
    d = _import(client)
    r = client.post("/api/backtest", headers=H, json={"dataset_id": d["id"], "timeframe": "5s", "duration_sec": 15,
                                                      "stake": 2, "payout": 0.9, "threshold": 30})
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["source"] == "import" and j["trades"] == j["wins"] + j["losses"] + j["draws"]
    assert abs(j["breakeven"] - 1 / 1.9) < 1e-9 and j["stake"] == 2
    # 10s n'est pas un multiple de 15s -> refusé
    bad = client.post("/api/backtest", headers=H, json={"dataset_id": d["id"], "timeframe": "15s", "duration_sec": 10})
    assert bad.status_code == 422
    assert client.post("/api/backtest", headers=H, json={"dataset_id": 9999, "timeframe": "5s", "duration_sec": 15}).status_code == 404


def test_backtest_refuses_seconds_from_minute_data(client):
    d = _import(client, tf=60, n=200)
    r = client.post("/api/backtest", headers=H, json={"dataset_id": d["id"], "timeframe": "5s", "duration_sec": 15})
    assert r.status_code == 422 and "timeframe_unsupported" in r.text


def test_replay_simulation_flow(client):
    d = _import(client)
    rp = client.post("/api/replay/start", headers=H, json={"dataset_id": d["id"], "timeframe": "5s", "duration_sec": 15,
                                                          "threshold": 20, "start_balance": 500}).json()
    assert rp["balance"] == 500 and "SIMULATION" in rp["label"]
    s = client.post(f"/api/replay/{rp['id']}/step", headers=H, json={"n": 5}).json()
    done = s["summary"]["wins"] + s["summary"]["losses"] + s["summary"]["draws"]
    assert 0 < done <= 5 and s["cursor"] > rp["cursor"]
    assert abs(s["balance"] - (500 + sum(t["profit"] for t in s["trades"]))) < 1e-6
    # jusqu'à la fin des données
    for _ in range(50):
        s = client.post(f"/api/replay/{rp['id']}/step", headers=H, json={"n": 500}).json()
        if s["finished"]:
            break
    assert s["finished"]
    st = client.get("/api/stats", headers=H).json()
    assert st["simulation"]["verified"] >= done
    assert st["total"] == st["won"] + st["lost"] + st["draw"] + st["pending"] + st["no_trade"] + \
        sum(1 for x in storage.list_signals(1000) if x["status"] == "unverifiable")


def test_halt_blocks_replay(client):
    d = _import(client)
    rp = client.post("/api/replay/start", headers=H, json={"dataset_id": d["id"], "timeframe": "5s", "duration_sec": 15}).json()
    client.post("/api/halt", headers=H, json={"halted": True})
    r = client.post(f"/api/replay/{rp['id']}/step", headers=H, json={"n": 1})
    assert r.status_code == 423
    client.post("/api/halt", headers=H, json={"halted": False})
    assert client.post(f"/api/replay/{rp['id']}/step", headers=H, json={"n": 1}).status_code == 200


def test_halt_blocks_simulated_orders(client, connected, monkeypatch):
    import trading
    storage.set_setting("halted", "1")
    sig = {"symbol": "EUR/USD OTC", "direction": "UP", "duration_sec": 15}
    import asyncio
    with pytest.raises(trading.TradeRejected):
        asyncio.run(trading.execute(sig, 1, "simulation", 1.0))


def test_risk_limits(client, connected, monkeypatch):
    import trading, asyncio
    from config import settings
    sig = {"symbol": "EUR/USD OTC", "direction": "UP", "duration_sec": 15}
    with pytest.raises(trading.TradeRejected):
        asyncio.run(trading.execute(sig, 1, "simulation", settings.MAX_STAKE + 1))
    monkeypatch.setattr(settings, "MAX_TRADES_PER_DAY", 0)
    with pytest.raises(trading.TradeRejected):
        asyncio.run(trading.execute(sig, 1, "simulation", 1.0))


def test_telegram_webhook_requires_secret(client):
    assert client.post("/telegram/webhook", json={}).status_code == 403
    import telegram_bot
    r = client.post("/telegram/webhook", json={}, headers={"X-Telegram-Bot-Api-Secret-Token": telegram_bot.webhook_secret()})
    assert r.status_code == 200


def test_telegram_user_needs_allow_list(client, monkeypatch):
    from test_security import signed
    from config import settings
    monkeypatch.setattr(settings, "ALLOWED_TELEGRAM_IDS", set())
    assert client.get("/api/config", headers={"X-Telegram-Init-Data": signed(42)}).status_code == 401
    monkeypatch.setattr(settings, "ALLOWED_TELEGRAM_IDS", {"42"})
    assert client.get("/api/config", headers={"X-Telegram-Init-Data": signed(42)}).status_code == 200


def test_pwa_files(client):
    assert client.get("/static/manifest.json").status_code == 200
    assert client.get("/static/icon-192.png").status_code == 200


def test_index_served(client):
    assert client.get("/").status_code == 200
