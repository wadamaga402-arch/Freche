import pytest
import engine
from conftest import make_candles


def test_uptrend_gives_positive_score():
    r = engine.analyze(make_candles(200, drift=0.2, wiggle=0.05), 60, 5)
    assert r["score"] > 0
    assert r["direction"] in ("UP", "NO_TRADE")


def test_downtrend_gives_negative_score():
    r = engine.analyze(make_candles(200, start=300, drift=-0.2, wiggle=0.05), 60, 5)
    assert r["score"] < 0


def test_forex_uses_buy_sell():
    r = engine.analyze(make_candles(200, drift=0.2, wiggle=0.05), 60, 5, market_type="forex")
    assert r["action"] in ("BUY", "NO_TRADE")


def test_stale_data_refused():
    old = make_candles(200, end=1_000_000)
    with pytest.raises(engine.DataError) as e:
        engine.analyze(old, 60, 5)
    assert e.value.code == "stale_data"


def test_insufficient_data_refused():
    with pytest.raises(engine.DataError):
        engine.analyze(make_candles(20), 60, 5)


def test_empty_data_refused():
    with pytest.raises(engine.DataError):
        engine.analyze([], 60, 5)


def test_horizon_reasons():
    keys = lambda r: [x["key"] for x in r["reasons"]]
    assert "horizon_short" in keys(engine.analyze(make_candles(200), 60, 15))
    assert "horizon_long" in keys(engine.analyze(make_candles(200, gran=5), 5, 3600))


def test_backtest_runs():
    res = engine.backtest(make_candles(300), 60, 180)
    assert res["trades"] == res["wins"] + res["losses"]


def test_backtest_requires_multiple():
    with pytest.raises(engine.DataError):
        engine.backtest(make_candles(300), 60, 90)


def test_threshold_controls_trades():
    c = make_candles(400, drift=0.0, wiggle=0.4)
    low = engine.backtest(c, 60, 60, threshold=20)
    high = engine.backtest(c, 60, 60, threshold=80)
    assert low["trades"] >= high["trades"]


def test_simulate_no_lookahead_and_rules():
    c = make_candles(300, drift=0.2, wiggle=0.05)
    events, nxt = engine.simulate(c, 60, 180, stake=2, payout=0.8, threshold=20)
    trades = [e for e in events if e["outcome"] in ("won", "lost", "draw")]
    assert trades
    for e in trades:
        assert e["entry"] == c[e["i"] - 1]["close"] and e["exit"] == c[e["i"] - 1 + 3]["close"]
        if e["outcome"] == "won":
            assert e["profit"] == 1.6
        if e["outcome"] == "lost":
            assert e["profit"] == -2
    # un seul trade à la fois : pas de chevauchement
    idx = [e["i"] for e in trades]
    assert all(b - a >= 3 for a, b in zip(idx, idx[1:]))


def test_simulate_skips_gaps():
    c = make_candles(300, drift=0.2, wiggle=0.05)
    for k in range(150, 300):
        c[k]["epoch"] += 600   # trou de 10 min dans les données
    events, _ = engine.simulate(c, 60, 180, threshold=20)
    for e in events:
        if e["outcome"] in ("won", "lost", "draw"):
            assert c[e["i"] - 1 + 3]["epoch"] - c[e["i"] - 1]["epoch"] == 180


def test_max_trades():
    c = make_candles(400, drift=0.2, wiggle=0.05)
    events, _ = engine.simulate(c, 60, 60, threshold=20, max_trades=3)
    assert sum(e["outcome"] in ("won", "lost", "draw") for e in events) <= 3


def test_summarize_math():
    ev = [{"outcome": "won", "profit": 0.85, "direction": "UP"}, {"outcome": "lost", "profit": -1, "direction": "DOWN"},
          {"outcome": "lost", "profit": -1, "direction": "UP"}, {"outcome": "draw", "profit": 0, "direction": "UP"},
          {"outcome": "no_trade", "profit": 0, "direction": "NO_TRADE"}]
    s = engine.summarize(ev, 1, 0.85, 100)
    assert (s["trades"], s["wins"], s["losses"], s["draws"], s["no_trade"]) == (4, 1, 2, 1, 1)
    assert s["final_balance"] == 98.85 and s["max_loss_streak"] == 2
    assert abs(s["max_drawdown"] - 2.0) < 1e-9
    assert abs(s["breakeven"] - 1 / 1.85) < 1e-9
    assert s["up"]["n"] == 2 and s["down"]["n"] == 1
