import indicators as ind
from conftest import make_candles


def test_ema_basic():
    vals = [1, 2, 3, 4, 5, 6]
    e = ind.ema(vals, 3)
    assert e[1] is None and e[2] == 2
    assert e[-1] > e[-2]


def test_rsi_bounds_and_direction():
    up = [float(i) for i in range(50)]
    assert ind.rsi(up) == 100.0
    down = [float(50 - i) for i in range(50)]
    assert ind.rsi(down) < 5


def test_atr_positive():
    assert ind.atr(make_candles(50)) > 0


def test_support_resistance_types():
    sup, res = ind.support_resistance(make_candles(120, drift=0.0))
    assert sup is None or isinstance(sup, float)
    assert res is None or isinstance(res, float)


def test_rsi_reference_wilder():
    # Série de référence classique (exemple de Wilder / StockCharts) : RSI(14) ≈ 70.5
    closes = [44.34, 44.09, 44.15, 43.61, 44.33, 44.83, 45.10, 45.42, 45.84, 46.08,
              45.89, 46.03, 45.61, 46.28, 46.28]
    assert abs(ind.rsi(closes, 14) - 70.5) < 0.3


def test_ema_exact_values():
    e = ind.ema([2, 4, 6, 8, 10], 3)
    assert e[2] == 4                     # moyenne simple de départ
    assert e[3] == 8 * 0.5 + 4 * 0.5     # k = 2/(3+1) = 0.5
    assert e[4] == 10 * 0.5 + 6 * 0.5


def test_atr_constant_range():
    c = [{"epoch": i, "open": 10, "high": 11, "low": 9, "close": 10} for i in range(30)]
    assert ind.atr(c, 14) == 2


def test_patterns():
    bull = [{"open": 10, "close": 9, "high": 10.1, "low": 8.9}, {"open": 8.9, "close": 10.2, "high": 10.3, "low": 8.8}]
    assert ind.candle_pattern(bull) == "bullish_engulfing"
    bear = [{"open": 9, "close": 10, "high": 10.1, "low": 8.9}, {"open": 10.1, "close": 8.8, "high": 10.2, "low": 8.7}]
    assert ind.candle_pattern(bear) == "bearish_engulfing"


def test_rate_of_change():
    assert ind.rate_of_change([100] * 10 + [110], 10) == 10
