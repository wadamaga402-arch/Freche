import time
import pytest
import market


def ticks(n, interval, end=None):
    end = end or int(time.time())
    times = [end - (n - 1 - i) * interval for i in range(n)]
    prices = [100 + (i % 7) * 0.01 for i in range(n)]
    return times, prices


def test_dense_ticks_build_real_candles():
    t, p = ticks(1000, 1)
    out = market.candles_from_ticks(t, p, 5)
    c = out["candles"]
    assert len(c) >= 199
    # chaque bougie vient de vrais ticks : high/low/open/close présents dans les prix
    assert all(x["high"] in p and x["low"] in p for x in c)


def test_sparse_ticks_refused():
    t, p = ticks(500, 4)       # 1 tick toutes les 4 s : trop espacé pour 5 s
    with pytest.raises(market.TimeframeUnsupported):
        market.candles_from_ticks(t, p, 5)


def test_irregular_ticks_refused():
    t, p = ticks(1000, 1)
    t = t[:300] + [x + 2000 for x in t[300:]]  # grand trou sans ticks
    with pytest.raises(market.TimeframeUnsupported):
        market.candles_from_ticks(t, p, 10)


def test_no_candle_invented_in_gap():
    t, p = ticks(600, 1)
    t = t[:300] + [x + 20 for x in t[300:]]  # petit trou de 20 s
    out = market.candles_from_ticks(t, p, 5)
    epochs = {c["epoch"] for c in out["candles"]}
    gap_start = t[299] - t[299] % 5 + 5
    assert gap_start not in epochs or any(gap_start <= x < gap_start + 5 for x in t)


def test_pocket_option_not_connected():
    st = market.status()
    assert st["platform"] == "Pocket Option"
    assert st["data_connected"] is False and st["execution_connected"] is False


def test_feed_refuses_to_give_prices():
    import asyncio
    with pytest.raises(market.PlatformNotConnected):
        asyncio.run(market.feed.get_candles_tf("EUR/USD OTC", 5))
    with pytest.raises(market.PlatformNotConnected):
        asyncio.run(market.feed.get_price_at("EUR/USD OTC", 0))


def test_requested_timeframes_and_expiries():
    assert list(market.TIMEFRAMES) == ["5s", "10s", "15s", "1m"]
    assert market.EXPIRY_CANDIDATES == [5, 10, 15, 60]


def test_otc_flag():
    assert market.is_otc("EUR/USD OTC") and not market.is_otc("EUR/USD")


def csv_text(n, tf, start=1_700_000_000, sep=",", ms=False):
    lines = [sep.join(["time", "open", "high", "low", "close"])]
    for i in range(n):
        o = 1.1 + (i % 9) * 1e-5
        ep = (start + i * tf) * (1000 if ms else 1)
        vals = [ep, o, o + 2e-5, o - 2e-5, o + 1e-5]
        txt = [str(v) for v in vals]
        if sep == ";":
            txt = [txt[0]] + [x.replace(".", ",") for x in txt[1:]]
        lines.append(sep.join(txt))
    return "\n".join(lines)


def test_csv_candles_5s_gives_all_timeframes():
    d = market.parse_csv_auto(csv_text(2000, 5))
    assert d["kind"] == "candles" and d["base_tf"] == 5
    assert d["timeframes"] == ["5s", "10s", "15s", "1m"]


def test_csv_1m_cannot_give_seconds():
    d = market.parse_csv_auto(csv_text(200, 60))
    assert d["timeframes"] == ["1m"]  # jamais de 5s inventées à partir de 1m
    with pytest.raises(market.TimeframeUnsupported):
        market.aggregate_candles(d["rows"], 60, 5)


def test_csv_semicolon_comma_decimal_and_ms():
    d = market.parse_csv_auto(csv_text(200, 15, sep=";", ms=True))
    assert d["base_tf"] == 15 and abs(d["rows"][0]["open"] - 1.1) < 1e-9
    assert d["rows"][0]["epoch"] == 1_700_000_000


def test_csv_iso_dates():
    lines = ["date,open,high,low,close"] + [
        f"2026-10-17 10:{i // 60:02d}:{i % 60:02d},1.1,1.2,1.0,1.15" for i in range(0, 3600, 5)][:200]
    d = market.parse_csv_auto("\n".join(lines))
    assert d["base_tf"] == 5


def test_csv_ticks():
    t, p = ticks(3000, 1, end=1_700_003_000)
    text = "time,price\n" + "\n".join(f"{a},{b}" for a, b in zip(t, p))
    d = market.parse_csv_auto(text)
    assert d["kind"] == "ticks" and "5s" in d["timeframes"] and "1m" not in d["timeframes"]  # 50 min < 80 bougies


def test_csv_errors():
    for bad in ("", "a,b\nc,d", csv_text(200, 7), csv_text(30, 5),
                csv_text(200, 5) + "\n1700999999,1,0.5,2,1",       # high < low
                "time,price\n1,1.1\n2,1.1,1.2,1.0,1.1"):           # mélange
        with pytest.raises(market.DataFormatError):
            market.parse_csv_auto(bad)


def test_aggregate_complete_periods_only():
    rows = market.parse_csv_auto(csv_text(200, 5))["rows"]
    agg = market.aggregate_candles(rows, 5, 15)
    assert all(a["epoch"] % 15 == 0 for a in agg)
    first = [r for r in rows if agg[0]["epoch"] <= r["epoch"] < agg[0]["epoch"] + 15]
    assert agg[0]["open"] == first[0]["open"] and agg[0]["close"] == first[-1]["close"]
    assert agg[0]["high"] == max(r["high"] for r in first)


def test_fmt_seconds():
    assert market.fmt_seconds(5) == "5s" and market.fmt_seconds(60) == "1m" and market.fmt_seconds(3600) == "1h"
