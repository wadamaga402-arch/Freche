import hashlib, hmac, json, time
from urllib.parse import urlencode
from security import verify_telegram_init_data, RateLimiter

TOKEN = "123456:TEST"


def signed(user_id=42, auth_date=None):
    data = {"auth_date": str(auth_date or int(time.time())), "query_id": "abc",
            "user": json.dumps({"id": user_id, "first_name": "Test"})}
    check = "\n".join(f"{k}={v}" for k, v in sorted(data.items()))
    secret = hmac.new(b"WebAppData", TOKEN.encode(), hashlib.sha256).digest()
    data["hash"] = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
    return urlencode(data)


def test_valid_init_data():
    assert verify_telegram_init_data(signed(), TOKEN)["id"] == 42


def test_tampered_init_data():
    assert verify_telegram_init_data(signed().replace("Test", "Hack"), TOKEN) is None


def test_wrong_token():
    assert verify_telegram_init_data(signed(), "999:OTHER") is None


def test_expired_init_data():
    assert verify_telegram_init_data(signed(auth_date=1000), TOKEN) is None


def test_rate_limiter():
    rl = RateLimiter(2)
    assert rl.check("a") and rl.check("a") and not rl.check("a")
