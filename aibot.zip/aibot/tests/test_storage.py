import storage


def test_outcome_rules():
    assert storage.resolve_outcome("UP", 1.0, 1.1) == "won"
    assert storage.resolve_outcome("UP", 1.0, 0.9) == "lost"
    assert storage.resolve_outcome("DOWN", 1.0, 0.9) == "won"
    assert storage.resolve_outcome("DOWN", 1.0, 1.0) == "draw"


def test_wilson():
    assert storage.wilson(0, 0) is None
    lo, hi = storage.wilson(55, 100)
    assert 0.44 < lo < 0.55 < hi < 0.65


def test_calibration_needs_samples():
    storage.init_db()
    assert storage.calibrated_confidence(60)["value"] is None
