import asyncio
import json
import httpx

import telegram_bot
from config import settings


def mock(monkeypatch):
    calls = []

    def handler(req):
        method = str(req.url).rsplit("/", 1)[-1]
        calls.append((method, json.loads(req.content or b"{}")))
        result = {"getMe": {"username": "test_bot"}, "getWebhookInfo": {"url": "x"}}.get(method, True)
        return httpx.Response(200, json={"ok": True, "result": result})
    monkeypatch.setattr(telegram_bot, "_transport", httpx.MockTransport(handler))
    monkeypatch.setattr(settings, "PUBLIC_URL", "https://bot.example.com")
    monkeypatch.setattr(settings, "ALLOWED_TELEGRAM_IDS", {"42"})
    return calls


def upd(uid, text="/start"):
    return {"message": {"text": text, "chat": {"id": uid}, "from": {"id": uid}}}


def test_secret_check():
    assert telegram_bot.check_secret(telegram_bot.webhook_secret())
    assert not telegram_bot.check_secret("wrong")


def test_start_allowed_gets_webapp_button(monkeypatch):
    calls = mock(monkeypatch)
    asyncio.run(telegram_bot.handle_update(upd(42)))
    method, body = calls[-1]
    assert method == "sendMessage"
    btn = body["reply_markup"]["inline_keyboard"][0][0]
    assert btn["web_app"]["url"] == "https://bot.example.com"
    assert "non connecté" in body["text"]


def test_start_refused_shows_id(monkeypatch):
    calls = mock(monkeypatch)
    asyncio.run(telegram_bot.handle_update(upd(7)))
    assert "reply_markup" not in calls[-1][1] and "7" in calls[-1][1]["text"]


def test_setup_registers_webhook_and_menu(monkeypatch):
    calls = mock(monkeypatch)
    out = asyncio.run(telegram_bot.setup())
    methods = [m for m, _ in calls]
    assert {"setWebhook", "setChatMenuButton", "setMyCommands", "getMe"} <= set(methods)
    wh = dict(calls)["setWebhook"]
    assert wh["url"] == "https://bot.example.com/telegram/webhook" and wh["secret_token"] == telegram_bot.webhook_secret()
    assert out["bot"] == "test_bot"
