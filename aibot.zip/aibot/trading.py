"""Exécution des ordres pour Pocket Option.

Pocket Option n'offre aucun moyen officiel de passer des ordres par programme.
=> Démo et réel : INDISPONIBLES. Aucun ordre n'est jamais simulé en se faisant passer pour réel.
=> Simulation : architecture conservée, mais elle n'est activable que si une source de prix
   autorisée est connectée (sinon impossible de vérifier le résultat d'un ordre virtuel).
Les limites de risque et l'arrêt d'urgence restent en place pour le jour où un accès officiel existe."""
from typing import Dict

import market
import storage
from config import settings

MODES = ("analysis", "simulation", "demo", "real")


class TradeRejected(Exception):
    pass


def available_modes() -> Dict[str, bool]:
    return {
        "analysis": True,
        "simulation": market.feed.connected,
        "demo": False,   # pas d'API officielle Pocket Option
        "real": False,   # pas d'API officielle Pocket Option
    }


def check_risk(mode: str, stake: float) -> None:
    if storage.get_setting("halted") == "1":
        raise TradeRejected("Arrêt d'urgence actif : aucun ordre n'est envoyé.")
    if stake <= 0 or stake > settings.MAX_STAKE:
        raise TradeRejected(f"Mise invalide (maximum autorisé : {settings.MAX_STAKE}).")
    t = storage.today_stats(mode)
    if t["count"] >= settings.MAX_TRADES_PER_DAY:
        raise TradeRejected("Nombre maximum de trades du jour atteint.")
    if t["loss"] >= settings.DAILY_LOSS_LIMIT:
        raise TradeRejected("Limite de perte journalière atteinte.")


async def execute(signal: Dict, signal_id: int, mode: str, stake: float, confirm_real: bool = False) -> Dict:
    if mode == "analysis":
        return {"status": "none", "message": "Mode analyse : aucun ordre."}
    if signal["direction"] not in ("UP", "DOWN"):
        return {"status": "none", "message": "NO TRADE : aucun ordre."}
    if not available_modes().get(mode):
        raise TradeRejected(market.feed.execution_reason if mode in ("demo", "real")
                            else "Simulation indisponible : aucune source de prix autorisée connectée.")
    check_risk(mode, stake)
    if mode == "simulation":
        tid = storage.insert_trade({"signal_id": signal_id, "mode": mode, "symbol": signal["symbol"],
                                    "direction": signal["direction"], "stake": stake,
                                    "duration_sec": signal["duration_sec"], "status": "open"})
        return {"status": "open", "trade_id": tid, "message": "Ordre SIMULÉ enregistré (aucun argent réel)."}
    raise TradeRejected("Mode inconnu.")


def settle_simulated(signal_id: int, outcome: str) -> None:
    for t in storage.trades_for_signal(signal_id):
        if t["mode"] != "simulation" or t["status"] != "open":
            continue
        profit = {"won": t["stake"] * settings.SIM_PAYOUT, "lost": -t["stake"]}.get(outcome, 0.0)
        storage.update_trade(t["id"], outcome, round(profit, 2))
        bal = float(storage.get_setting("sim_balance")) + profit
        storage.set_setting("sim_balance", round(bal, 2))
